# GraphAPI — Microsoft Graph AD Group Member Fetcher

Fetches users from one or more Azure AD groups using the Microsoft Graph API
with **Client Credentials** (Application) authentication.

---

## Setup (3 steps)

### Step 1 — Fill in `application.properties`

```properties
azure.tenant.id=YOUR_TENANT_ID
azure.client.id=YOUR_CLIENT_ID
azure.client.secret=YOUR_CLIENT_SECRET
azure.ad.group.ids=GROUP_OBJECT_ID_1,GROUP_OBJECT_ID_2
```

Get these values from:
`Azure Portal → Azure Active Directory → App Registrations → <your app>`

---

### Step 2 — Fix the PKIX / SSL error (one-time)

The app needs Microsoft's intermediate CA certificate to trust
`login.microsoftonline.com`. Run this once to generate the file:

**Linux / Mac / Git Bash:**
```bash
openssl s_client -connect login.microsoftonline.com:443 -showcerts \
  </dev/null 2>/dev/null \
  | awk '/BEGIN CERT/{f=1} f{print} /END CERT/{f=0}' \
  | awk 'BEGIN{n=0} /BEGIN CERT/{n++} n==2{print}' \
  > src/main/resources/certs/ms-azure-tls-ca.pem
```

**Already have the .crt file?**
```bash
openssl x509 -in microsoft-azure-rsa-tls-ca04.crt \
             -out src/main/resources/certs/ms-azure-tls-ca.pem \
             -inform DER
```

The file must start with `-----BEGIN CERTIFICATE-----`.

---

### Step 3 — Build and run

```bash
mvn clean package -DskipTests
java -jar target/GraphAPI-1.0.0.jar
```

---

## Azure AD App Registration permissions required

| Permission       | Type        | Purpose                        |
|------------------|-------------|--------------------------------|
| Group.Read.All   | Application | Read group members             |
| User.Read.All    | Application | Read full user profiles        |

Both need **admin consent** granted in the Azure portal.

---

## Project structure

```
src/main/
├── java/com/kalai/graphapi/
│   ├── GraphApiApplication.java       ← main() — entry point
│   ├── config/
│   │   └── GraphClientConfig.java     ← builds GraphServiceClient
│   ├── model/
│   │   └── UserDetail.java            ← user POJO
│   ├── service/
│   │   └── GraphUserService.java      ← pagination + deduplication
│   └── util/
│       ├── AppProperties.java         ← typed config loader
│       ├── ResultPrinter.java         ← JSON console output
│       └── SslTrustFix.java           ← PKIX fix (in-memory, no keytool)
└── resources/
    ├── application.properties
    ├── log4j2.xml
    └── certs/
        └── ms-azure-tls-ca.pem        ← Microsoft intermediate CA cert (you generate this)
```
