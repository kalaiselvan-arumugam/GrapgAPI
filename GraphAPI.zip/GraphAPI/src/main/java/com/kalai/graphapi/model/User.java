package com.kalai.graphapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a Microsoft Azure AD / Entra ID user as returned by the
 * Microsoft Graph API {@code /groups/{id}/members/microsoft.graph.user} endpoint.
 *
 * <p>Fields are mapped directly from the JSON response using Jackson annotations.
 * Unknown JSON fields are silently ignored ({@code @JsonIgnoreProperties(ignoreUnknown = true)})
 * to stay resilient against future Graph API additions.</p>
 *
 * <p>In addition to the Graph API fields, a {@code groupIds} set is maintained
 * in-memory to track which AD groups this user belongs to (used for deduplication
 * when the same user appears in multiple groups).</p>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

    // ------------------------------------------------------------------
    // Core identity fields
    // ------------------------------------------------------------------

    /** Azure AD Object ID (GUID) — globally unique, used as the deduplication key. */
    @JsonProperty("id")
    private String id;

    /** Full display name (e.g. "John Doe"). */
    @JsonProperty("displayName")
    private String displayName;

    /** User Principal Name (UPN) — typically the login email (e.g. "john.doe@contoso.com"). */
    @JsonProperty("userPrincipalName")
    private String userPrincipalName;

    /** Primary SMTP email address. May differ from UPN for guest/external users. */
    @JsonProperty("mail")
    private String mail;

    /** First / given name. */
    @JsonProperty("givenName")
    private String givenName;

    /** Last / family name. */
    @JsonProperty("surname")
    private String surname;

    // ------------------------------------------------------------------
    // Organisational / HR fields
    // ------------------------------------------------------------------

    /** Job title (e.g. "Software Engineer"). */
    @JsonProperty("jobTitle")
    private String jobTitle;

    /** Department the user belongs to (e.g. "Engineering"). */
    @JsonProperty("department")
    private String department;

    /** Physical office location (e.g. "Chennai HQ"). */
    @JsonProperty("officeLocation")
    private String officeLocation;

    /** Company name associated with the user. */
    @JsonProperty("companyName")
    private String companyName;

    // ------------------------------------------------------------------
    // Contact fields
    // ------------------------------------------------------------------

    /** Mobile / cell phone number. */
    @JsonProperty("mobilePhone")
    private String mobilePhone;

    /** List of business phone numbers (Graph API always returns this as an array). */
    @JsonProperty("businessPhones")
    private List<String> businessPhones;

    // ------------------------------------------------------------------
    // Account state
    // ------------------------------------------------------------------

    /** {@code true} if the account is active; {@code false} if disabled. */
    @JsonProperty("accountEnabled")
    private Boolean accountEnabled;

    /** ISO-8601 date-time string of when the user was created in Azure AD. */
    @JsonProperty("createdDateTime")
    private String createdDateTime;

    // ------------------------------------------------------------------
    // In-memory group membership tracking (NOT from Graph API JSON)
    // ------------------------------------------------------------------

    /**
     * Set of AD group Object IDs that this user is a member of.
     * Populated by the application during fetch, not by the Graph API response.
     */
    private final Set<String> groupIds = new HashSet<>();

    // ------------------------------------------------------------------
    // Constructors
    // ------------------------------------------------------------------

    /** Default no-arg constructor required by Jackson. */
    public User() {}

    // ------------------------------------------------------------------
    // Business methods
    // ------------------------------------------------------------------

    /**
     * Registers a group membership for this user.
     *
     * @param groupId the Azure AD Object ID of the group
     */
    public void addGroupId(String groupId) {
        this.groupIds.add(groupId);
    }

    /**
     * Merges another user's group memberships into this instance.
     * Used when the same user is found in multiple AD groups.
     *
     * @param other the duplicate user entry from another group
     */
    public void mergeGroupsFrom(User other) {
        this.groupIds.addAll(other.groupIds);
    }

    /**
     * Returns the primary business phone if available, or an empty string.
     */
    public String getPrimaryBusinessPhone() {
        if (businessPhones != null && !businessPhones.isEmpty()) {
            return businessPhones.get(0);
        }
        return "";
    }

    // ------------------------------------------------------------------
    // Getters & Setters
    // ------------------------------------------------------------------

    public String getId()                   { return id; }
    public void setId(String id)            { this.id = id; }

    public String getDisplayName()          { return displayName; }
    public void setDisplayName(String v)    { this.displayName = v; }

    public String getUserPrincipalName()    { return userPrincipalName; }
    public void setUserPrincipalName(String v) { this.userPrincipalName = v; }

    public String getMail()                 { return mail; }
    public void setMail(String v)           { this.mail = v; }

    public String getGivenName()            { return givenName; }
    public void setGivenName(String v)      { this.givenName = v; }

    public String getSurname()              { return surname; }
    public void setSurname(String v)        { this.surname = v; }

    public String getJobTitle()             { return jobTitle; }
    public void setJobTitle(String v)       { this.jobTitle = v; }

    public String getDepartment()           { return department; }
    public void setDepartment(String v)     { this.department = v; }

    public String getOfficeLocation()       { return officeLocation; }
    public void setOfficeLocation(String v) { this.officeLocation = v; }

    public String getCompanyName()          { return companyName; }
    public void setCompanyName(String v)    { this.companyName = v; }

    public String getMobilePhone()          { return mobilePhone; }
    public void setMobilePhone(String v)    { this.mobilePhone = v; }

    public List<String> getBusinessPhones()          { return businessPhones; }
    public void setBusinessPhones(List<String> v)    { this.businessPhones = v; }

    public Boolean getAccountEnabled()      { return accountEnabled; }
    public void setAccountEnabled(Boolean v){ this.accountEnabled = v; }

    public String getCreatedDateTime()      { return createdDateTime; }
    public void setCreatedDateTime(String v){ this.createdDateTime = v; }

    public Set<String> getGroupIds()        { return groupIds; }

    // ------------------------------------------------------------------
    // toString – for logging/debugging
    // ------------------------------------------------------------------

    @Override
    public String toString() {
        return "User{" +
               "id='" + id + '\'' +
               ", displayName='" + displayName + '\'' +
               ", upn='" + userPrincipalName + '\'' +
               ", mail='" + mail + '\'' +
               ", jobTitle='" + jobTitle + '\'' +
               ", department='" + department + '\'' +
               ", accountEnabled=" + accountEnabled +
               ", groupIds=" + groupIds +
               '}';
    }
}
