package com.kalai.graphapi.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * Loads and exposes all configuration values from {@code application.properties}.
 *
 * <p>Call {@link #load()} once at startup. The resulting instance is then passed
 * through the service layer so every component reads from a single source of truth.</p>
 *
 * <p>Required Azure AD permissions (Application, NOT Delegated):
 * <ul>
 *   <li>{@code GroupMember.Read.All}  – read members of any group</li>
 *   <li>{@code User.Read.All}         – read full user profiles</li>
 * </ul>
 * </p>
 */
public class GraphApiConfig {

    private static final Logger logger = LogManager.getLogger(GraphApiConfig.class);
    private static final String PROPERTIES_FILE = "application.properties";

    /* ------------------------------------------------------------------ */
    /*  Azure AD credentials                                                */
    /* ------------------------------------------------------------------ */
    private final String tenantId;
    private final String clientId;
    private final String clientSecret;

    /* ------------------------------------------------------------------ */
    /*  Graph API endpoints / settings                                      */
    /* ------------------------------------------------------------------ */
    private final String graphApiBaseUrl;
    private final String graphApiScope;
    private final String tokenUrlTemplate;   // contains {tenant} placeholder
    private final int    pageSize;

    /* ------------------------------------------------------------------ */
    /*  AD groups to process                                                */
    /* ------------------------------------------------------------------ */
    private final List<String> groupIds;

    /* ------------------------------------------------------------------ */
    /*  HTTP client settings                                                */
    /* ------------------------------------------------------------------ */
    private final int connectTimeoutSeconds;
    private final int requestTimeoutSeconds;
    private final int retryMaxAttempts;
    private final long retryWaitMs;

    // -----------------------------------------------------------------------
    // Private constructor – use load() factory method
    // -----------------------------------------------------------------------
    private GraphApiConfig(Properties props) {
        this.tenantId             = require(props, "azure.tenant.id");
        this.clientId             = require(props, "azure.client.id");
        this.clientSecret         = require(props, "azure.client.secret");

        this.graphApiBaseUrl      = require(props, "graph.api.base.url");
        this.graphApiScope        = require(props, "graph.api.scope");
        this.tokenUrlTemplate     = require(props, "graph.api.token.url");
        this.pageSize             = parseInt(props, "graph.api.page.size", 999);

        // Parse comma-separated group IDs, trimming whitespace around each entry
        String rawGroupIds        = require(props, "ad.group.ids");
        this.groupIds             = Arrays.stream(rawGroupIds.split(","))
                                         .map(String::trim)
                                         .filter(s -> !s.isEmpty())
                                         .collect(Collectors.toList());

        this.connectTimeoutSeconds = parseInt(props, "http.connect.timeout.seconds", 30);
        this.requestTimeoutSeconds = parseInt(props, "http.request.timeout.seconds", 60);
        this.retryMaxAttempts      = parseInt(props, "http.retry.max.attempts", 3);
        this.retryWaitMs           = parseLong(props, "http.retry.wait.ms", 2000L);
    }

    // -----------------------------------------------------------------------
    // Factory method
    // -----------------------------------------------------------------------

    /**
     * Loads {@code application.properties} from the classpath and returns a
     * fully validated {@link GraphApiConfig} instance.
     *
     * @return configured instance
     * @throws RuntimeException if the file is missing or a required key is absent
     */
    public static GraphApiConfig load() {
        logger.info("Loading configuration from classpath:{}", PROPERTIES_FILE);

        Properties props = new Properties();
        try (InputStream is = GraphApiConfig.class
                .getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {

            if (is == null) {
                throw new IllegalStateException(
                        "Cannot find '" + PROPERTIES_FILE + "' on the classpath. " +
                        "Ensure it is present in src/main/resources/");
            }
            props.load(is);

        } catch (IOException e) {
            throw new RuntimeException("Failed to read " + PROPERTIES_FILE, e);
        }

        GraphApiConfig config = new GraphApiConfig(props);
        config.logSummary();
        return config;
    }

    // -----------------------------------------------------------------------
    // Helper: require a property value (throws if missing/blank)
    // -----------------------------------------------------------------------
    private static String require(Properties props, String key) {
        String value = props.getProperty(key);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(
                    "Required property '" + key + "' is missing or empty in " + PROPERTIES_FILE);
        }
        return value.trim();
    }

    private static int parseInt(Properties props, String key, int defaultValue) {
        String raw = props.getProperty(key);
        if (raw == null || raw.isBlank()) return defaultValue;
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            logger.warn("Property '{}' has non-integer value '{}'; using default {}", key, raw, defaultValue);
            return defaultValue;
        }
    }

    private static long parseLong(Properties props, String key, long defaultValue) {
        String raw = props.getProperty(key);
        if (raw == null || raw.isBlank()) return defaultValue;
        try {
            return Long.parseLong(raw.trim());
        } catch (NumberFormatException e) {
            logger.warn("Property '{}' has non-long value '{}'; using default {}", key, raw, defaultValue);
            return defaultValue;
        }
    }

    /** Logs a sanitised summary of loaded config (secrets are masked). */
    private void logSummary() {
        logger.info("--- Configuration Summary ---");
        logger.info("  Tenant ID      : {}", tenantId);
        logger.info("  Client ID      : {}", clientId);
        logger.info("  Client Secret  : [REDACTED]");
        logger.info("  Graph Base URL : {}", graphApiBaseUrl);
        logger.info("  Page Size      : {}", pageSize);
        logger.info("  AD Groups ({}) : {}", groupIds.size(), groupIds);
        logger.info("  Retry attempts : {}", retryMaxAttempts);
        logger.info("-----------------------------");
    }

    // -----------------------------------------------------------------------
    // Derived / computed helpers
    // -----------------------------------------------------------------------

    /**
     * Returns the fully-resolved OAuth2 token endpoint URL, with the
     * {@code {tenant}} placeholder replaced by the configured tenant ID.
     */
    public String getTokenUrl() {
        return tokenUrlTemplate.replace("{tenant}", tenantId);
    }

    // -----------------------------------------------------------------------
    // Getters
    // -----------------------------------------------------------------------

    public String getTenantId()              { return tenantId; }
    public String getClientId()              { return clientId; }
    public String getClientSecret()          { return clientSecret; }
    public String getGraphApiBaseUrl()       { return graphApiBaseUrl; }
    public String getGraphApiScope()         { return graphApiScope; }
    public int    getPageSize()              { return pageSize; }
    public List<String> getGroupIds()        { return groupIds; }
    public int    getConnectTimeoutSeconds() { return connectTimeoutSeconds; }
    public int    getRequestTimeoutSeconds() { return requestTimeoutSeconds; }
    public int    getRetryMaxAttempts()      { return retryMaxAttempts; }
    public long   getRetryWaitMs()           { return retryWaitMs; }
}
