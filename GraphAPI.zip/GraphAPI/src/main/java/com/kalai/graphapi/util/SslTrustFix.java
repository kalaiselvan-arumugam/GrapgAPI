package com.kalai.graphapi.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * Fixes the {@code PKIX path building failed} error that occurs when Java's
 * default truststore does not include Microsoft's intermediate CA certificate.
 *
 * <h3>Why this happens</h3>
 * When the Graph SDK connects to {@code login.microsoftonline.com}, Java
 * validates the server's certificate chain:
 * <pre>
 *   stamp2.login.microsoftonline.com        ← server cert (leaf)
 *     signed by: Microsoft Azure RSA TLS Issuing CA 04   ← intermediate CA
 *       signed by: DigiCert Global Root G2               ← root CA
 * </pre>
 * Older Java distributions or restricted enterprise environments may be
 * missing the intermediate CA, causing the PKIX error even though the root
 * CA is present.
 *
 * <h3>What this class does</h3>
 * <ol>
 *   <li>Loads the Microsoft intermediate CA certificate from the classpath
 *       ({@code certs/ms-azure-tls-ca.pem}).</li>
 *   <li>Merges it with Java's existing default truststore ({@code cacerts})
 *       in memory — the file on disk is never modified.</li>
 *   <li>Installs the merged truststore as the JVM's default {@link SSLContext}
 *       so all HTTPS connections made by the app use it automatically.</li>
 * </ol>
 *
 * <h3>How to obtain the PEM file (one-time setup)</h3>
 * Run the following command and save the output to
 * {@code src/main/resources/certs/ms-azure-tls-ca.pem}:
 * <pre>
 *   openssl s_client -connect login.microsoftonline.com:443 -showcerts \
 *     &lt;/dev/null 2&gt;/dev/null \
 *     | awk '/BEGIN CERT/{f=1} f{print} /END CERT/{f=0}' \
 *     | awk 'BEGIN{n=0} /BEGIN CERT/{n++} n==2{print}' \
 *     &gt; src/main/resources/certs/ms-azure-tls-ca.pem
 * </pre>
 * This extracts the second certificate in the chain (the intermediate CA).
 */
public final class SslTrustFix {

    private static final Logger log = LogManager.getLogger(SslTrustFix.class);

    private SslTrustFix() {}

    // =========================================================================
    // Public API
    // =========================================================================

    /**
     * Applies the SSL trust fix if enabled in {@code application.properties}.
     *
     * <p>Call this <strong>once, before any HTTPS call is made</strong> —
     * ideally as the very first line of {@code main()}.
     *
     * <p>If the fix is disabled ({@code ssl.trust.fix.enabled=false}) or the
     * cert file is not found on the classpath, the method logs a warning and
     * returns without throwing — normal JVM trust behaviour is preserved.
     */
    public static void applyIfEnabled() {
        if (!AppProperties.isSslTrustFixEnabled()) {
            log.info("SSL trust fix is disabled (ssl.trust.fix.enabled=false)");
            return;
        }

        String certPath = AppProperties.getSslTrustFixCertPath();
        log.info("Applying SSL trust fix — loading cert from classpath:{}", certPath);

        try {
            apply(certPath);
            log.info("SSL trust fix applied successfully — Microsoft CA cert trusted");
        } catch (Exception e) {
            /*
             * Log as a warning rather than aborting. The app may still work
             * if the JVM already trusts the Microsoft CA chain.
             */
            log.warn("SSL trust fix failed ({}). Continuing with default JVM trust — " +
                     "if you see PKIX errors, check that '{}' exists on the classpath.",
                     e.getMessage(), certPath);
            log.debug("SSL trust fix stack trace:", e);
        }
    }

    // =========================================================================
    // Core logic
    // =========================================================================

    /**
     * Loads {@code certClasspath}, merges it into the default JVM truststore,
     * and installs the result as the default {@link SSLContext}.
     *
     * @param certClasspath classpath-relative path to the PEM certificate file
     * @throws Exception on any keystore, certificate, or SSL context error
     */
    private static void apply(String certClasspath) throws Exception {

        // ── Step 1: Load the PEM certificate from classpath ──────────────────
        X509Certificate microsoftCa = loadCertFromClasspath(certClasspath);
        log.debug("Loaded cert: subject='{}', issuer='{}'",
                  microsoftCa.getSubjectX500Principal().getName(),
                  microsoftCa.getIssuerX500Principal().getName());

        // ── Step 2: Load the JVM's default truststore (cacerts) ──────────────
        // Passing null loads the platform default (JAVA_HOME/lib/security/cacerts)
        TrustManagerFactory defaultTmf = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        defaultTmf.init((KeyStore) null);

        // Extract the default X509TrustManager
        X509TrustManager defaultTm = getX509TrustManager(defaultTmf);

        // ── Step 3: Create a new in-memory KeyStore with the Microsoft cert ──
        KeyStore customStore = KeyStore.getInstance(KeyStore.getDefaultType());
        customStore.load(null, null);  // initialise empty
        customStore.setCertificateEntry("microsoft-azure-rsa-tls-ca", microsoftCa);

        // Build a TrustManager backed by the custom store
        TrustManagerFactory customTmf = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        customTmf.init(customStore);
        X509TrustManager customTm = getX509TrustManager(customTmf);

        // ── Step 4: Compose a merged TrustManager ────────────────────────────
        // First tries the custom store (Microsoft CA), then falls back to the
        // default JVM cacerts. This way no existing trusted certs are removed.
        X509TrustManager mergedTm = new X509TrustManager() {

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                // Combine accepted issuers from both trust managers
                X509Certificate[] defaultIssuers = defaultTm.getAcceptedIssuers();
                X509Certificate[] customIssuers  = customTm.getAcceptedIssuers();

                X509Certificate[] combined =
                        new X509Certificate[defaultIssuers.length + customIssuers.length];
                System.arraycopy(defaultIssuers, 0, combined, 0, defaultIssuers.length);
                System.arraycopy(customIssuers, 0, combined, defaultIssuers.length,
                                 customIssuers.length);
                return combined;
            }

            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType)
                    throws java.security.cert.CertificateException {
                // Client cert checking — delegate to default
                defaultTm.checkClientTrusted(chain, authType);
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType)
                    throws java.security.cert.CertificateException {
                // Try the default JVM cacerts first
                try {
                    defaultTm.checkServerTrusted(chain, authType);
                    log.debug("Server cert trusted via default JVM cacerts");
                } catch (java.security.cert.CertificateException e) {
                    // Default failed — try the custom store (Microsoft CA)
                    log.debug("Default trust failed, trying custom Microsoft CA store...");
                    customTm.checkServerTrusted(chain, authType);
                    log.debug("Server cert trusted via custom Microsoft CA store");
                }
            }
        };

        // ── Step 5: Install the merged TrustManager as the JVM default ───────
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{mergedTm}, null);
        SSLContext.setDefault(sslContext);

        log.debug("Custom SSLContext installed as JVM default");
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /**
     * Loads an X.509 certificate (PEM or DER) from the classpath.
     *
     * @param classpathPath resource path relative to the classpath root
     * @return parsed {@link X509Certificate}
     * @throws Exception if the resource is not found or cannot be parsed
     */
    private static X509Certificate loadCertFromClasspath(String classpathPath)
            throws Exception {

        try (InputStream is = SslTrustFix.class
                .getClassLoader()
                .getResourceAsStream(classpathPath)) {

            if (is == null) {
                throw new IllegalStateException(
                    "Certificate file not found on classpath: '" + classpathPath + "'. " +
                    "Please follow the setup instructions in SslTrustFix.java to " +
                    "generate the file and place it under src/main/resources/" + classpathPath);
            }

            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            return (X509Certificate) cf.generateCertificate(is);
        }
    }

    /**
     * Extracts the {@link X509TrustManager} from a {@link TrustManagerFactory}.
     *
     * @param factory initialised factory
     * @return first X509TrustManager found
     * @throws IllegalStateException if no X509TrustManager is present
     */
    private static X509TrustManager getX509TrustManager(TrustManagerFactory factory) {
        for (TrustManager tm : factory.getTrustManagers()) {
            if (tm instanceof X509TrustManager) {
                return (X509TrustManager) tm;
            }
        }
        throw new IllegalStateException(
            "No X509TrustManager found in TrustManagerFactory. " +
            "This is unexpected — please report this as a bug.");
    }
}
