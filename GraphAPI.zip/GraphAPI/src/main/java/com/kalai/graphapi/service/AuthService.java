package com.kalai.graphapi.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kalai.graphapi.config.GraphApiConfig;
import com.kalai.graphapi.util.HttpClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;

/**
 * Handles OAuth2 authentication against the Microsoft Identity Platform using
 * the <em>Client Credentials</em> flow (application access — no user sign-in).
 *
 * <p>Token endpoint called:
 * <pre>
 *   POST https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token
 * </pre>
 * </p>
 *
 * <p>Required Azure AD app registration permissions (Application type):
 * <ul>
 *   <li>{@code GroupMember.Read.All}</li>
 *   <li>{@code User.Read.All}</li>
 * </ul>
 * Grant admin consent for these permissions in the Azure Portal.
 * </p>
 *
 * <p>The acquired token is cached in memory. Before each use the expiry time is
 * checked; if the token will expire within the next 60 seconds a fresh token
 * is fetched automatically.</p>
 */
public class AuthService {

    private static final Logger logger = LogManager.getLogger(AuthService.class);

    /** Refresh the token this many seconds before it actually expires (safety buffer). */
    private static final int TOKEN_EXPIRY_BUFFER_SECONDS = 60;

    private final GraphApiConfig config;
    private final HttpClientUtil httpClient;
    private final ObjectMapper   objectMapper;

    /** Cached access token value. */
    private String cachedToken;

    /** Unix epoch second when the cached token expires. */
    private long   tokenExpiresAt;

    /**
     * @param config     loaded application configuration
     * @param httpClient shared HTTP client utility
     */
    public AuthService(GraphApiConfig config, HttpClientUtil httpClient) {
        this.config       = config;
        this.httpClient   = httpClient;
        this.objectMapper = new ObjectMapper();
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Returns a valid Bearer access token for the Microsoft Graph API.
     *
     * <p>If a non-expired token is already cached, it is returned immediately
     * without making a network call. Otherwise a new token is fetched from
     * the Azure AD token endpoint.</p>
     *
     * @return the access token string (without the "Bearer " prefix)
     * @throws RuntimeException on authentication failure
     */
    public String getAccessToken() {
        if (isCachedTokenValid()) {
            logger.debug("Returning cached access token (expires in ~{}s)",
                    tokenExpiresAt - Instant.now().getEpochSecond());
            return cachedToken;
        }

        logger.info("Requesting new access token from Azure AD [tenantId={}]", config.getTenantId());
        fetchNewToken();
        return cachedToken;
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Returns {@code true} if the cached token exists and will not expire
     * within the next {@value TOKEN_EXPIRY_BUFFER_SECONDS} seconds.
     */
    private boolean isCachedTokenValid() {
        if (cachedToken == null || cachedToken.isBlank()) return false;
        long nowSeconds = Instant.now().getEpochSecond();
        return (tokenExpiresAt - nowSeconds) > TOKEN_EXPIRY_BUFFER_SECONDS;
    }

    /**
     * Calls the Azure AD OAuth2 token endpoint and caches the result.
     *
     * <p>Request body (x-www-form-urlencoded):
     * <pre>
     *   grant_type    = client_credentials
     *   client_id     = {clientId}
     *   client_secret = {clientSecret}
     *   scope         = https://graph.microsoft.com/.default
     * </pre>
     * </p>
     */
    private void fetchNewToken() {
        String tokenUrl  = config.getTokenUrl();
        String formBody  = buildTokenRequestBody();

        try {
            String responseBody = httpClient.post(tokenUrl, formBody);
            parseAndCacheToken(responseBody);
            logger.info("Access token acquired successfully (expires in ~{}s)",
                    tokenExpiresAt - Instant.now().getEpochSecond());

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to acquire access token from Azure AD. " +
                    "Check tenant ID, client ID, client secret, and app permissions.", e);
        }
    }

    /**
     * Builds the URL-encoded form body for the client credentials token request.
     */
    private String buildTokenRequestBody() {
        // All values must be URL-encoded to handle special characters in secrets
        return "grant_type=client_credentials"
             + "&client_id="     + urlEncode(config.getClientId())
             + "&client_secret=" + urlEncode(config.getClientSecret())
             + "&scope="         + urlEncode(config.getGraphApiScope());
    }

    /**
     * Parses the JSON token response, extracts {@code access_token} and
     * {@code expires_in}, then caches both values.
     *
     * <p>Expected JSON response structure:
     * <pre>
     * {
     *   "token_type"  : "Bearer",
     *   "expires_in"  : 3599,
     *   "access_token": "eyJ0eXAiOiJKV1Q..."
     * }
     * </pre>
     * </p>
     */
    private void parseAndCacheToken(String responseJson) throws Exception {
        JsonNode root = objectMapper.readTree(responseJson);

        // Detect and surface authentication errors (e.g. wrong credentials)
        if (root.has("error")) {
            String error            = root.path("error").asText();
            String errorDescription = root.path("error_description").asText();
            throw new RuntimeException(
                    "Azure AD token error: " + error + " — " + errorDescription);
        }

        String token    = root.path("access_token").asText();
        long expiresIn  = root.path("expires_in").asLong(3600);

        if (token.isBlank()) {
            throw new RuntimeException(
                    "Token response did not contain an access_token. Response: " + responseJson);
        }

        this.cachedToken    = token;
        this.tokenExpiresAt = Instant.now().getEpochSecond() + expiresIn;

        logger.debug("Token cached. expires_in={}s, expiresAt={}",
                expiresIn, Instant.ofEpochSecond(tokenExpiresAt));
    }

    /** URL-encodes a string using UTF-8 encoding. */
    private static String urlEncode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
