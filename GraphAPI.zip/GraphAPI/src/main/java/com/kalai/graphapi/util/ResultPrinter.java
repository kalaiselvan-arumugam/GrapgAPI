package com.kalai.graphapi.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kalai.graphapi.model.UserDetail;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * Utility that serialises the final {@link UserDetail} map to JSON and prints
 * it to the console via the logger.
 *
 * <p>Output format (per user):
 * <pre>{@code
 * {
 *   "id"                : "00000000-0000-0000-0000-000000000000",
 *   "displayName"       : "Jane Doe",
 *   "mail"              : "jane.doe@contoso.com",
 *   "userPrincipalName" : "jane.doe@contoso.com",
 *   "jobTitle"          : "Software Engineer",
 *   "department"        : "Engineering",
 *   "officeLocation"    : "Building A",
 *   "mobilePhone"       : "+1 555-0123",
 *   "groups"            : ["Engineering-All", "Dev-Backend"]
 * }
 * }</pre>
 */
public final class ResultPrinter {

    private static final Logger log = LogManager.getLogger(ResultPrinter.class);

    /** Re-usable Jackson mapper; not modified after construction so thread-safe. */
    private static final ObjectMapper MAPPER_PRETTY =
            new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

    private static final ObjectMapper MAPPER_COMPACT = new ObjectMapper();

    /** Private constructor — utility class. */
    private ResultPrinter() {}

    // =========================================================================
    // Public API
    // =========================================================================

    /**
     * Serialises {@code userMap} to a JSON array and logs it.
     *
     * @param userMap     map of Object ID → {@link UserDetail}
     * @param prettyPrint {@code true} to indent the JSON output
     */
    public static void printResults(Map<String, UserDetail> userMap, boolean prettyPrint) {

        log.info("══════════════════════════════════════════════════════");
        log.info("FINAL RESULT — {} unique user(s)", userMap.size());
        log.info("══════════════════════════════════════════════════════");

        if (userMap.isEmpty()) {
            log.info("No users found. Verify group IDs and App permissions in Azure portal.");
            return;
        }

        try {
            ObjectMapper mapper = prettyPrint ? MAPPER_PRETTY : MAPPER_COMPACT;

            ArrayNode array = mapper.createArrayNode();

            for (UserDetail user : userMap.values()) {
                ObjectNode node = mapper.createObjectNode();

                node.put("id",                 nullSafe(user.getId()));
                node.put("displayName",        nullSafe(user.getDisplayName()));
                node.put("mail",               nullSafe(user.getMail()));
                node.put("userPrincipalName",  nullSafe(user.getUserPrincipalName()));
                node.put("jobTitle",           nullSafe(user.getJobTitle()));
                node.put("department",         nullSafe(user.getDepartment()));
                node.put("officeLocation",     nullSafe(user.getOfficeLocation()));
                node.put("mobilePhone",        nullSafe(user.getMobilePhone()));

                // Groups array
                ArrayNode groupsArray = node.putArray("groups");
                user.getGroupNames().forEach(groupsArray::add);

                array.add(node);
            }

            String json = mapper.writeValueAsString(array);

            // Split by newline so each line is a separate log entry (avoids
            // console truncation with very large payloads)
            for (String line : json.split("\n")) {
                log.info("{}", line);
            }

        } catch (Exception e) {
            log.error("Failed to serialise results to JSON: {}", e.getMessage(), e);
        }
    }

    /**
     * Logs a per-group membership summary — useful for auditing.
     *
     * @param userMap map of Object ID → {@link UserDetail}
     */
    public static void printGroupSummary(Map<String, UserDetail> userMap) {

        log.info("──────────────────────────────────────────────────────");
        log.info("GROUP MEMBERSHIP SUMMARY");
        log.info("──────────────────────────────────────────────────────");

        // Collect unique group names across all users
        Map<String, Long> groupCount = new java.util.LinkedHashMap<>();
        for (UserDetail user : userMap.values()) {
            for (String g : user.getGroupNames()) {
                groupCount.merge(g, 1L, Long::sum);
            }
        }

        if (groupCount.isEmpty()) {
            log.info("No group data available.");
            return;
        }

        groupCount.forEach((group, count) ->
            log.info("  {:50s} → {} user(s)", group, count)
        );

        // Users present in more than one queried group
        long multiGroupUsers = userMap.values().stream()
                .filter(u -> u.getGroupNames().size() > 1)
                .count();

        log.info("──────────────────────────────────────────────────────");
        log.info("Users spanning multiple groups: {}", multiGroupUsers);
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /** Returns {@code value} if non-null, otherwise an empty string. */
    private static String nullSafe(String value) {
        return value != null ? value : "";
    }
}
