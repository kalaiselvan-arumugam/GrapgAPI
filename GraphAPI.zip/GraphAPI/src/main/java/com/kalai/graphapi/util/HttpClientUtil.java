package com.kalai.graphapi.util;

import com.kalai.graphapi.config.GraphApiConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Set;

/**
 * Utility wrapper around Java's built-in {@link HttpClient} (introduced in Java 11).
 *
 * <p>Responsibilities:</p>
 * <ul>
 *   <li>Creates a shared, single-instance {@link HttpClient} with configured timeouts</li>
 *   <li>Provides a {@link #get(String, String)} helper for authenticated Graph API calls</li>
 *   <li>Implements retry logic for transient HTTP errors (429, 503, 504)</li>
 *   <li>Handles {@code Retry-After} header on 429 responses</li>
 * </ul>
 */
public class HttpClientUtil {

    private static final Logger logger = LogManager.getLogger(HttpClientUtil.class);

    /** HTTP status codes that are considered transient and safe to retry. */
    private static final Set<Integer> RETRYABLE_STATUS_CODES = Set.of(429, 503, 504);

    private final HttpClient httpClient;
    private final int        retryMaxAttempts;
    private final long       retryWaitMs;

    /**
     * Constructs an {@link HttpClientUtil} with timeouts and retry settings
     * sourced from the application configuration.
     *
     * @param config the loaded application configuration
     */
    public HttpClientUtil(GraphApiConfig config) {
        this.retryMaxAttempts = config.getRetryMaxAttempts();
        this.retryWaitMs      = config.getRetryWaitMs();

        // Build a shared HttpClient with connection timeout.
        // HttpClient is thread-safe and should be reused across requests.
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(config.getConnectTimeoutSeconds()))
                .version(HttpClient.Version.HTTP_2)   // prefer HTTP/2, falls back to 1.1
                .build();

        logger.debug("HttpClient initialised [connectTimeout={}s, requestTimeout={}s, retries={}]",
                config.getConnectTimeoutSeconds(),
                config.getRequestTimeoutSeconds(),
                retryMaxAttempts);
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Executes an HTTP GET request to the given URL, attaching a Bearer token
     * for authentication. Retries on transient failures up to the configured limit.
     *
     * @param url         the fully-qualified URL to call
     * @param bearerToken the OAuth2 access token (without the "Bearer " prefix)
     * @return the raw JSON response body as a {@link String}
     * @throws IOException          on network / IO failures
     * @throws InterruptedException if the thread is interrupted while waiting
     * @throws RuntimeException     if all retry attempts are exhausted
     */
    public String get(String url, String bearerToken) throws IOException, InterruptedException {
        logger.debug("HTTP GET → {}", url);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + bearerToken)
                .header("Accept", "application/json")
                // ConsistencyLevel is required when using $count or $filter on members
                .header("ConsistencyLevel", "eventual")
                .GET()
                .build();

        return executeWithRetry(request);
    }

    /**
     * Executes an HTTP POST with an {@code application/x-www-form-urlencoded} body.
     * Used exclusively for the OAuth2 token endpoint (no auth header required here).
     *
     * @param url      the token endpoint URL
     * @param formBody URL-encoded form parameters string
     * @return the raw JSON response body
     * @throws IOException          on network / IO failures
     * @throws InterruptedException if the thread is interrupted while waiting
     */
    public String post(String url, String formBody) throws IOException, InterruptedException {
        logger.debug("HTTP POST → {}", url);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(formBody))
                .build();

        return executeWithRetry(request);
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Executes an {@link HttpRequest}, retrying on transient errors.
     *
     * <p>Retry strategy:</p>
     * <ol>
     *   <li>On HTTP 429 (Too Many Requests), honour the {@code Retry-After} header
     *       if present, otherwise fall back to the configured {@code retryWaitMs}.</li>
     *   <li>On HTTP 503 / 504, wait {@code retryWaitMs} then retry.</li>
     *   <li>On non-2xx status codes that are NOT retryable, throw immediately.</li>
     * </ol>
     *
     * @param request the prepared HTTP request
     * @return response body string on success (2xx)
     */
    private String executeWithRetry(HttpRequest request) throws IOException, InterruptedException {
        int attempt = 0;

        while (true) {
            attempt++;
            logger.debug("Attempt {}/{} for {}", attempt, retryMaxAttempts, request.uri());

            HttpResponse<String> response = httpClient.send(
                    request, HttpResponse.BodyHandlers.ofString());

            int statusCode = response.statusCode();

            // Success path
            if (statusCode >= 200 && statusCode < 300) {
                logger.debug("HTTP {} OK for {}", statusCode, request.uri());
                return response.body();
            }

            // Retryable error path
            if (RETRYABLE_STATUS_CODES.contains(statusCode) && attempt < retryMaxAttempts) {
                long waitMs = resolveRetryWait(response, statusCode);
                logger.warn("HTTP {} received on attempt {}. Retrying after {}ms... [{}]",
                        statusCode, attempt, waitMs, request.uri());
                Thread.sleep(waitMs);
                continue;   // next iteration = next attempt
            }

            // Non-retryable or exhausted retries
            String errorMsg = String.format(
                    "HTTP request failed after %d attempt(s). Status: %d, URL: %s, Body: %s",
                    attempt, statusCode, request.uri(), response.body());
            logger.error(errorMsg);
            throw new RuntimeException(errorMsg);
        }
    }

    /**
     * Determines how long to wait before the next retry.
     *
     * <p>If the server sent a {@code Retry-After} header (value in seconds),
     * that value takes precedence; otherwise the configured default is used.</p>
     */
    private long resolveRetryWait(HttpResponse<String> response, int statusCode) {
        if (statusCode == 429) {
            return response.headers()
                           .firstValue("Retry-After")
                           .map(v -> {
                               try {
                                   long seconds = Long.parseLong(v.trim());
                                   logger.debug("Server requested Retry-After: {}s", seconds);
                                   return seconds * 1000L;   // convert to milliseconds
                               } catch (NumberFormatException ex) {
                                   return retryWaitMs;
                               }
                           })
                           .orElse(retryWaitMs);
        }
        return retryWaitMs;
    }
}
