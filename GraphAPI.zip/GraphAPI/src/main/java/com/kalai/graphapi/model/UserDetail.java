package com.kalai.graphapi.model;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Immutable-ish value object representing a single Azure AD user and the
 * set of AD groups they were found in during this run.
 *
 * <p>The {@code groupNames} set is mutable so that the service layer can
 * accumulate group memberships when the same user appears in multiple groups
 * without creating a new object each time.
 */
public class UserDetail {

    // -------------------------------------------------------------------------
    // Fields
    // -------------------------------------------------------------------------

    /** Azure AD Object ID — globally unique, used as the deduplication key. */
    private final String id;

    /** User's display name (e.g. "John Doe"). */
    private final String displayName;

    /** Primary SMTP address (may be null for service/guest accounts). */
    private final String mail;

    /** User Principal Name — login identity (e.g. "john.doe@contoso.com"). */
    private final String userPrincipalName;

    /** Job title from the directory profile. */
    private final String jobTitle;

    /** Department the user belongs to. */
    private final String department;

    /** Office location. */
    private final String officeLocation;

    /** Mobile phone number. */
    private final String mobilePhone;

    /**
     * Names (display names) of every AD group in which this user was found.
     * Maintained as an ordered set to avoid duplicates while preserving
     * insertion order.
     */
    private final Set<String> groupNames = new LinkedHashSet<>();

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /**
     * Constructs a {@code UserDetail} using the builder.
     * Use {@link Builder} to create instances.
     */
    private UserDetail(Builder builder) {
        this.id                 = builder.id;
        this.displayName        = builder.displayName;
        this.mail               = builder.mail;
        this.userPrincipalName  = builder.userPrincipalName;
        this.jobTitle           = builder.jobTitle;
        this.department         = builder.department;
        this.officeLocation     = builder.officeLocation;
        this.mobilePhone        = builder.mobilePhone;
    }

    // -------------------------------------------------------------------------
    // Group membership helpers
    // -------------------------------------------------------------------------

    /**
     * Registers {@code groupName} as a group this user belongs to.
     *
     * @param groupName AD group display name
     */
    public void addGroup(String groupName) {
        if (groupName != null && !groupName.isBlank()) {
            groupNames.add(groupName);
        }
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public String getId()               { return id; }
    public String getDisplayName()      { return displayName; }
    public String getMail()             { return mail; }
    public String getUserPrincipalName(){ return userPrincipalName; }
    public String getJobTitle()         { return jobTitle; }
    public String getDepartment()       { return department; }
    public String getOfficeLocation()   { return officeLocation; }
    public String getMobilePhone()      { return mobilePhone; }

    /**
     * @return unmodifiable view of the group names this user belongs to
     */
    public Set<String> getGroupNames() {
        return Collections.unmodifiableSet(groupNames);
    }

    // -------------------------------------------------------------------------
    // Object overrides
    // -------------------------------------------------------------------------

    @Override
    public String toString() {
        return "UserDetail{" +
               "id='"                + id                + '\'' +
               ", displayName='"     + displayName       + '\'' +
               ", mail='"            + mail              + '\'' +
               ", userPrincipalName='"+ userPrincipalName + '\'' +
               ", jobTitle='"        + jobTitle          + '\'' +
               ", department='"      + department        + '\'' +
               ", officeLocation='"  + officeLocation    + '\'' +
               ", mobilePhone='"     + mobilePhone       + '\'' +
               ", groups="           + groupNames        +
               '}';
    }

    // =========================================================================
    // Builder
    // =========================================================================

    /**
     * Fluent builder for {@link UserDetail}.
     *
     * <pre>{@code
     * UserDetail user = new UserDetail.Builder("some-object-id")
     *         .displayName("Jane Doe")
     *         .mail("jane.doe@contoso.com")
     *         .build();
     * }</pre>
     */
    public static final class Builder {

        private final String id;           // mandatory
        private String displayName;
        private String mail;
        private String userPrincipalName;
        private String jobTitle;
        private String department;
        private String officeLocation;
        private String mobilePhone;

        /**
         * @param id Azure AD Object ID — mandatory, must not be null
         */
        public Builder(String id) {
            if (id == null || id.isBlank()) {
                throw new IllegalArgumentException("UserDetail.id must not be null or blank");
            }
            this.id = id;
        }

        public Builder displayName(String v)       { this.displayName       = v; return this; }
        public Builder mail(String v)              { this.mail              = v; return this; }
        public Builder userPrincipalName(String v) { this.userPrincipalName = v; return this; }
        public Builder jobTitle(String v)          { this.jobTitle          = v; return this; }
        public Builder department(String v)        { this.department        = v; return this; }
        public Builder officeLocation(String v)    { this.officeLocation    = v; return this; }
        public Builder mobilePhone(String v)       { this.mobilePhone       = v; return this; }

        /**
         * @return new {@link UserDetail} instance
         */
        public UserDetail build() {
            return new UserDetail(this);
        }
    }
}
