package com.kalai.graphapi.service;

import com.kalai.graphapi.model.UserDetail;
import com.kalai.graphapi.util.AppProperties;
import com.microsoft.graph.core.tasks.PageIterator;
import com.microsoft.graph.models.Group;
import com.microsoft.graph.models.User;
import com.microsoft.graph.models.UserCollectionResponse;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * Service class that encapsulates all Microsoft Graph API calls needed to
 * enumerate users across one or more Azure AD groups.
 *
 * <h3>Key behaviours</h3>
 * <ul>
 *   <li><strong>Pagination</strong> — uses {@link PageIterator} to transparently
 *       walk through all {@code @odata.nextLink} pages, so groups with 1 000+
 *       members are handled automatically.</li>
 *   <li><strong>Deduplication</strong> — a user present in multiple groups is
 *       stored once; all group memberships are accumulated in
 *       {@link UserDetail#getGroupNames()}.</li>
 *   <li><strong>Members only</strong> — the request is cast to
 *       {@code /members/microsoft.graph.user} so only {@code User} objects are
 *       returned (service principals, devices, nested groups are excluded).</li>
 * </ul>
 *
 * <h3>Graph API permissions required (Application type)</h3>
 * <ul>
 *   <li>{@code Group.Read.All}</li>
 *   <li>{@code User.Read.All}</li>
 * </ul>
 */
public class GraphUserService {

    private static final Logger log = LogManager.getLogger(GraphUserService.class);

    /**
     * User properties to retrieve — avoids fetching the full 100+ field schema.
     * Add or remove fields here as needed; the Graph API ignores unknown fields.
     */
    private static final String[] USER_SELECT_FIELDS = {
        "id",
        "displayName",
        "mail",
        "userPrincipalName",
        "jobTitle",
        "department",
        "officeLocation",
        "mobilePhone"
    };

    // -------------------------------------------------------------------------
    // Dependencies
    // -------------------------------------------------------------------------

    /** Authenticated Graph client injected at construction time. */
    private final GraphServiceClient graphClient;

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /**
     * @param graphClient authenticated {@link GraphServiceClient} — must not be null
     */
    public GraphUserService(GraphServiceClient graphClient) {
        Objects.requireNonNull(graphClient, "graphClient must not be null");
        this.graphClient = graphClient;
    }

    // =========================================================================
    // Public API
    // =========================================================================

    /**
     * Fetches users from <em>all</em> AD groups listed in
     * {@code application.properties}, deduplicating across groups.
     *
     * <p>Each returned {@link UserDetail} carries the full set of groups it
     * belongs to (among those queried) via {@link UserDetail#getGroupNames()}.
     *
     * @return unmodifiable map keyed by Azure AD Object ID → {@link UserDetail}
     */
    public Map<String, UserDetail> fetchUsersFromAllGroups() {

        List<String> groupIds = AppProperties.getGroupIds();

        log.info("Starting user fetch for {} AD group(s): {}", groupIds.size(), groupIds);

        /*
         * Accumulator map: Object ID → UserDetail
         * LinkedHashMap preserves insertion order for predictable output.
         */
        Map<String, UserDetail> userMap = new LinkedHashMap<>();

        int groupIndex = 0;
        for (String groupId : groupIds) {
            groupIndex++;
            log.info("──────────────────────────────────────────────────────");
            log.info("Processing group [{}/{}] — ID: {}", groupIndex, groupIds.size(), groupId);

            // Resolve the human-readable display name for this group
            String groupName = resolveGroupDisplayName(groupId);

            log.info("Group display name: '{}'", groupName);

            // Fetch all members and merge them into the accumulator
            fetchGroupMembers(groupId, groupName, userMap);
        }

        log.info("══════════════════════════════════════════════════════");
        log.info("Completed: {} unique user(s) found across {} group(s)",
                 userMap.size(), groupIds.size());

        return Collections.unmodifiableMap(userMap);
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    /**
     * Resolves the display name of an AD group by its Object ID.
     *
     * <p>Returns the raw Object ID as a fallback if the API call fails, so
     * that processing of other groups can continue.
     *
     * @param groupId Azure AD group Object ID
     * @return display name, or the Object ID itself on error
     */
    private String resolveGroupDisplayName(String groupId) {
        try {
            Group group = graphClient
                    .groups()
                    .byGroupId(groupId)
                    .get(requestConfig ->
                        requestConfig.queryParameters.select =
                            new String[]{"id", "displayName"}
                    );

            if (group != null && group.getDisplayName() != null) {
                return group.getDisplayName();
            }

        } catch (Exception e) {
            log.warn("Could not resolve display name for group '{}': {}", groupId, e.getMessage());
        }

        // Fallback: use the Object ID itself as the group label
        return groupId;
    }

    /**
     * Fetches all direct members (users only) of one group and merges them
     * into {@code userMap}.
     *
     * <h4>Pagination strategy</h4>
     * The Graph API returns at most {@code $top} users per page (max 999).
     * {@link PageIterator} automatically follows {@code @odata.nextLink} until
     * no more pages remain, so the caller receives every member regardless of
     * group size.
     *
     * <h4>Deduplication strategy</h4>
     * If a user already exists in {@code userMap} (seen in a previous group),
     * the current group name is simply appended to their {@code groupNames} set.
     * No duplicate {@link UserDetail} objects are created.
     *
     * @param groupId   Azure AD group Object ID
     * @param groupName human-readable group display name (for labelling)
     * @param userMap   accumulator map to merge results into
     */
    private void fetchGroupMembers(
            String groupId,
            String groupName,
            Map<String, UserDetail> userMap) {

        int pageSize = AppProperties.getPageSize();
        int[] pageCount = {0};   // array trick to allow mutation inside lambda
        int[] userCount = {0};

        log.debug("Requesting members of '{}' (page size={})", groupName, pageSize);

        try {
            // ------------------------------------------------------------------
            // 1. First page request
            //    /groups/{id}/members/microsoft.graph.user
            //    ?$select=id,displayName,...&$top=999
            // ------------------------------------------------------------------
            UserCollectionResponse firstPage = graphClient
                    .groups()
                    .byGroupId(groupId)
                    .members()
                    .graphUser()
                    .get(requestConfig -> {
                        requestConfig.queryParameters.select = USER_SELECT_FIELDS;
                        requestConfig.queryParameters.top    = pageSize;
                    });

            if (firstPage == null || firstPage.getValue() == null) {
                log.warn("No members returned for group '{}' (null response)", groupName);
                return;
            }

            log.debug("First page received for '{}' — {} user(s) on page 1",
                      groupName, firstPage.getValue().size());

            // ------------------------------------------------------------------
            // 2. PageIterator — automatically follows @odata.nextLink
            // ------------------------------------------------------------------
            PageIterator<User, UserCollectionResponse> pageIterator =
                new PageIterator.Builder<User, UserCollectionResponse>()
                    .client(graphClient)
                    .collectionPage(firstPage)
                    .collectionPageFactory(
                        UserCollectionResponse::createFromDiscriminatorValue)
                    .processPageItemCallback(user -> {

                        // Called once per User on every page
                        mergeUser(user, groupName, userMap);
                        userCount[0]++;

                        // Log progress every 100 users for large groups
                        if (userCount[0] % 100 == 0) {
                            log.debug("  … processed {} users in '{}'",
                                      userCount[0], groupName);
                        }

                        return true; // return false to stop iteration early
                    })
                    .onPageCallback(page -> {
                        // Called once per page (after all items on that page are processed)
                        pageCount[0]++;
                        log.debug("Page {} complete for group '{}'",
                                  pageCount[0], groupName);
                        return true; // return false to stop after this page
                    })
                    .build();

            pageIterator.iterate();

            log.info("Group '{}' — {} user(s) fetched across {} page(s)",
                     groupName, userCount[0], pageCount[0]);

        } catch (Exception e) {
            /*
             * Log and continue rather than aborting the entire run.
             * Common causes: group not found (404), missing permissions (403),
             * transient network error (500/503).
             */
            log.error("Failed to fetch members of group '{}' (id={}): {}",
                      groupName, groupId, e.getMessage(), e);
        }
    }

    /**
     * Converts a Graph SDK {@link User} object into a {@link UserDetail} and
     * either inserts it into {@code userMap} (first occurrence) or appends the
     * group name to an existing entry (duplicate).
     *
     * @param user      raw Graph API {@link User} object
     * @param groupName display name of the group this user was found in
     * @param userMap   accumulator map keyed by Object ID
     */
    private void mergeUser(
            User user,
            String groupName,
            Map<String, UserDetail> userMap) {

        String objectId = user.getId();

        if (objectId == null || objectId.isBlank()) {
            log.warn("Skipping user with null/blank Object ID (displayName='{}')",
                     user.getDisplayName());
            return;
        }

        if (userMap.containsKey(objectId)) {
            // -----------------------------------------------------------------
            // Duplicate: user already seen in a previous group.
            // Just register the new group membership.
            // -----------------------------------------------------------------
            userMap.get(objectId).addGroup(groupName);
            log.debug("Duplicate user '{}' (id={}) also found in group '{}' — group appended",
                      user.getDisplayName(), objectId, groupName);
        } else {
            // -----------------------------------------------------------------
            // New user: build a UserDetail and insert into the map.
            // -----------------------------------------------------------------
            UserDetail detail = new UserDetail.Builder(objectId)
                    .displayName(user.getDisplayName())
                    .mail(user.getMail())
                    .userPrincipalName(user.getUserPrincipalName())
                    .jobTitle(user.getJobTitle())
                    .department(user.getDepartment())
                    .officeLocation(user.getOfficeLocation())
                    .mobilePhone(user.getMobilePhone())
                    .build();

            detail.addGroup(groupName);
            userMap.put(objectId, detail);

            log.debug("New user added: '{}' ({})", detail.getDisplayName(), objectId);
        }
    }
}
