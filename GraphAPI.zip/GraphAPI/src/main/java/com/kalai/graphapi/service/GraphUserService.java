package com.kalai.graphapi.service;

import com.kalai.graphapi.model.UserDetail;
import com.kalai.graphapi.util.AppProperties;
import com.microsoft.graph.models.Group;
import com.microsoft.graph.models.User;
import com.microsoft.graph.models.UserCollectionResponse;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * Core service that fetches AD group members from the Microsoft Graph API.
 *
 * <h3>Key behaviours</h3>
 * <ul>
 *   <li><strong>Pagination</strong> — manually follows {@code @odata.nextLink}
 *       in a simple while-loop. No third-party iterator builder is involved,
 *       so there are no SDK version surprises. Groups with 1 000+ members are
 *       handled transparently.</li>
 *   <li><strong>Deduplication</strong> — a user found in multiple groups is
 *       stored once; every matched group name is accumulated inside
 *       {@link UserDetail#getGroupNames()}.</li>
 *   <li><strong>Users only</strong> — the request targets
 *       {@code /members/microsoft.graph.user}, so nested groups, service
 *       principals, and devices are automatically excluded.</li>
 * </ul>
 *
 * <h3>Required App Registration permissions (Application type)</h3>
 * <ul>
 *   <li>{@code Group.Read.All}</li>
 *   <li>{@code User.Read.All}</li>
 * </ul>
 */
public class GraphUserService {

    private static final Logger log = LogManager.getLogger(GraphUserService.class);

    /**
     * $select fields requested from the Graph API.
     * Add extra fields here as needed; unused fields incur no cost.
     */
    private static final String[] USER_SELECT_FIELDS = {
        "id",
        "displayName",
        "mail",
        "userPrincipalName",
        "jobTitle",
        "department",
        "officeLocation",
        "mobilePhone"
    };

    private final GraphServiceClient graphClient;

    /**
     * @param graphClient authenticated Graph client — must not be null
     */
    public GraphUserService(GraphServiceClient graphClient) {
        Objects.requireNonNull(graphClient, "graphClient must not be null");
        this.graphClient = graphClient;
    }

    // =========================================================================
    // Public API
    // =========================================================================

    /**
     * Fetches and deduplicates users from every AD group listed in
     * {@code application.properties}.
     *
     * @return unmodifiable map of Azure AD Object ID → {@link UserDetail}
     */
    public Map<String, UserDetail> fetchUsersFromAllGroups() {

        List<String> groupIds = AppProperties.getGroupIds();
        log.info("Starting user fetch for {} group(s): {}", groupIds.size(), groupIds);

        // LinkedHashMap preserves insertion order for consistent output
        Map<String, UserDetail> userMap = new LinkedHashMap<>();

        int index = 0;
        for (String groupId : groupIds) {
            index++;
            log.info("──────────────────────────────────────────────");
            log.info("Processing group [{}/{}]  id={}", index, groupIds.size(), groupId);

            String groupName = resolveGroupDisplayName(groupId);
            log.info("Group display name: '{}'", groupName);

            fetchGroupMembers(groupId, groupName, userMap);
        }

        log.info("══════════════════════════════════════════════");
        log.info("Completed: {} unique user(s) found across {} group(s)",
                 userMap.size(), groupIds.size());

        return Collections.unmodifiableMap(userMap);
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    /**
     * Resolves the human-readable display name for a group.
     * Falls back to the Object ID if the call fails (e.g. permission denied).
     *
     * @param groupId Azure AD group Object ID
     * @return display name, or {@code groupId} on error
     */
    private String resolveGroupDisplayName(String groupId) {
        try {
            Group group = graphClient
                    .groups()
                    .byGroupId(groupId)
                    .get(cfg -> cfg.queryParameters.select = new String[]{"id", "displayName"});

            if (group != null && group.getDisplayName() != null) {
                return group.getDisplayName();
            }
        } catch (Exception e) {
            log.warn("Could not resolve display name for group '{}': {}", groupId, e.getMessage());
        }
        return groupId;  // safe fallback
    }

    /**
     * Fetches <em>all</em> direct user-members of one group and merges them
     * into {@code userMap}.
     *
     * <h4>Pagination</h4>
     * The Graph API returns at most {@code $top} records per response (max 999).
     * When more pages exist, the response includes an {@code @odata.nextLink}
     * URL.  This method fetches pages in a plain while-loop until that link is
     * absent, at which point all members have been retrieved.
     *
     * <pre>
     *   Page 1  GET /groups/{id}/members/microsoft.graph.user?$top=999
     *           ← { value: [...999 users...], "@odata.nextLink": "https://..." }
     *   Page 2  GET &lt;nextLink&gt;
     *           ← { value: [...500 users...] }   // no nextLink = last page
     * </pre>
     *
     * <h4>Deduplication</h4>
     * If a user's Object ID is already in {@code userMap} (seen in an earlier
     * group), only the new group name is appended — no duplicate entry is created.
     *
     * @param groupId   Azure AD group Object ID
     * @param groupName display name used as the group label in output
     * @param userMap   accumulator map (modified in place)
     */
    private void fetchGroupMembers(
            String groupId,
            String groupName,
            Map<String, UserDetail> userMap) {

        int pageSize  = AppProperties.getPageSize();
        int pageNum   = 0;
        int userCount = 0;

        log.debug("Fetching members of '{}' (pageSize={})", groupName, pageSize);

        try {
            // ── First page ───────────────────────────────────────────────────
            // GET /groups/{id}/members/microsoft.graph.user?$select=...&$top=999
            UserCollectionResponse page = graphClient
                    .groups()
                    .byGroupId(groupId)
                    .members()
                    .graphUser()
                    .get(cfg -> {
                        cfg.queryParameters.select = USER_SELECT_FIELDS;
                        cfg.queryParameters.top    = pageSize;
                    });

            // ── Pagination loop ───────────────────────────────────────────────
            // Continue while there is a valid page with results.
            while (page != null && page.getValue() != null && !page.getValue().isEmpty()) {

                pageNum++;
                List<User> users = page.getValue();
                log.debug("Page {} — {} user(s) in '{}'", pageNum, users.size(), groupName);

                for (User user : users) {
                    mergeUser(user, groupName, userMap);
                    userCount++;

                    if (userCount % 100 == 0) {
                        log.debug("  … {} users processed in '{}'", userCount, groupName);
                    }
                }

                // Follow @odata.nextLink if present, otherwise we are done
                String nextLink = page.getOdataNextLink();
                if (nextLink == null || nextLink.isBlank()) {
                    break;  // last page reached
                }

                log.debug("Following nextLink (page {}) for '{}'", pageNum + 1, groupName);

                // Fetch the next page using the pre-built nextLink URL.
                // The nextLink already encodes $top, $select, and the skip token.
                page = graphClient
                        .groups()
                        .byGroupId(groupId)
                        .members()
                        .graphUser()
                        .withUrl(nextLink)
                        .get();
            }

            log.info("Group '{}' — {} user(s) fetched across {} page(s)",
                     groupName, userCount, pageNum);

        } catch (Exception e) {
            // Log and continue — don't abort other groups due to one failure.
            // Common causes: 404 (group not found), 403 (missing permission),
            //                503 (transient Graph API error).
            log.error("Failed to fetch members of group '{}' (id={}): {}",
                      groupName, groupId, e.getMessage(), e);
        }
    }

    /**
     * Converts a Graph API {@link User} object to a {@link UserDetail} and
     * inserts it into {@code userMap}, or appends the group name to an
     * existing entry if the user was already seen in a previous group.
     *
     * @param user      Graph SDK user object
     * @param groupName group this user was found in
     * @param userMap   accumulator map
     */
    private void mergeUser(User user, String groupName, Map<String, UserDetail> userMap) {

        String objectId = user.getId();

        if (objectId == null || objectId.isBlank()) {
            log.warn("Skipping user with null/blank Object ID (displayName='{}')",
                     user.getDisplayName());
            return;
        }

        if (userMap.containsKey(objectId)) {
            // User already seen in a previous group — just add the new group label
            userMap.get(objectId).addGroup(groupName);
            log.debug("Duplicate '{}' ({}) — appended group '{}'",
                      user.getDisplayName(), objectId, groupName);
        } else {
            // First time seeing this user — build a full entry
            UserDetail detail = new UserDetail.Builder(objectId)
                    .displayName(user.getDisplayName())
                    .mail(user.getMail())
                    .userPrincipalName(user.getUserPrincipalName())
                    .jobTitle(user.getJobTitle())
                    .department(user.getDepartment())
                    .officeLocation(user.getOfficeLocation())
                    .mobilePhone(user.getMobilePhone())
                    .build();

            detail.addGroup(groupName);
            userMap.put(objectId, detail);

            log.debug("Added user '{}' ({})", detail.getDisplayName(), objectId);
        }
    }
}
