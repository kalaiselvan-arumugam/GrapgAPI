package com.kalai.graphapi.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kalai.graphapi.config.GraphApiConfig;
import com.kalai.graphapi.model.User;
import com.kalai.graphapi.util.HttpClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Core service for fetching user data from Microsoft Graph API.
 *
 * <p><strong>Two-phase execution:</strong></p>
 * <ol>
 *   <li><strong>Resolution phase</strong> — each group display name
 *       (e.g. {@code SM-APPLICATION-ADMIN}) is resolved to its Azure AD
 *       Object ID via {@code GET /groups?$filter=displayName eq '...'}.</li>
 *   <li><strong>Fetch phase</strong> — members are retrieved for each resolved
 *       Object ID, with full pagination ({@code @odata.nextLink}) to handle
 *       1000+ users, and cross-group deduplication.</li>
 * </ol>
 *
 * <p>Graph API endpoints used:</p>
 * <pre>
 *   // Phase 1 – resolve group name to Object ID
 *   GET /v1.0/groups?$filter=displayName eq 'SM-APPLICATION-ADMIN'
 *                  &$select=id,displayName
 *
 *   // Phase 2 – fetch members by Object ID (paginated)
 *   GET /v1.0/groups/{objectId}/members/microsoft.graph.user
 *             ?$select=id,displayName,...
 *             &$top=999
 *             &$count=true
 * </pre>
 *
 * <p>Required Azure AD app permissions (Application type):</p>
 * <ul>
 *   <li>{@code Group.Read.All}       – for the name→ID resolution query</li>
 *   <li>{@code GroupMember.Read.All} – for reading group members</li>
 *   <li>{@code User.Read.All}        – for reading full user profiles</li>
 * </ul>
 */
public class GraphService {

    private static final Logger logger = LogManager.getLogger(GraphService.class);

    /**
     * The set of user fields to retrieve from Graph API.
     * Only request what you need to keep responses lean and fast.
     */
    private static final String SELECT_FIELDS =
            "id,displayName,userPrincipalName,mail,givenName,surname," +
            "jobTitle,department,officeLocation,companyName," +
            "mobilePhone,businessPhones,accountEnabled,createdDateTime";

    private final GraphApiConfig config;
    private final HttpClientUtil httpClient;
    private final AuthService    authService;
    private final ObjectMapper   objectMapper;

    /**
     * @param config      loaded application configuration
     * @param httpClient  shared HTTP client utility
     * @param authService service used to obtain (and refresh) the access token
     */
    public GraphService(GraphApiConfig config,
                        HttpClientUtil httpClient,
                        AuthService    authService) {
        this.config       = config;
        this.httpClient   = httpClient;
        this.authService  = authService;
        this.objectMapper = new ObjectMapper();
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Entry point: resolves all configured group names to Object IDs, then
     * fetches and deduplicates users across all groups.
     *
     * @return a {@link Map} of Azure AD Object ID → {@link User},
     *         preserving insertion order (via {@link LinkedHashMap})
     */
    public Map<String, User> fetchUsersFromAllGroups() {
        List<String> groupNames = config.getGroupNames();
        logger.info("Starting user fetch for {} AD group(s): {}", groupNames.size(), groupNames);

        // ------------------------------------------------------------------
        // Phase 1: Resolve each group display name → Object ID
        // ------------------------------------------------------------------
        Map<String, String> groupNameToId = resolveGroupNamesToIds(groupNames);

        if (groupNameToId.isEmpty()) {
            logger.warn("No groups could be resolved. Verify group names and app permissions.");
            return new LinkedHashMap<>();
        }

        // ------------------------------------------------------------------
        // Phase 2: Fetch members for each resolved group Object ID
        // ------------------------------------------------------------------
        Map<String, User> aggregatedUsers = new LinkedHashMap<>();
        int groupIndex = 0;

        for (Map.Entry<String, String> entry : groupNameToId.entrySet()) {
            String groupName = entry.getKey();
            String groupId   = entry.getValue();
            groupIndex++;

            logger.info("--- Processing group {}/{}: '{}' [objectId={}] ---",
                    groupIndex, groupNameToId.size(), groupName, groupId);

            try {
                List<User> groupUsers = fetchAllUsersFromGroup(groupId, groupName);
                logger.info("Group '{}': fetched {} user(s)", groupName, groupUsers.size());

                // Merge into aggregate map — deduplicate by user Object ID
                for (User user : groupUsers) {
                    aggregatedUsers.merge(user.getId(), user, (existing, incoming) -> {
                        existing.mergeGroupsFrom(incoming);
                        logger.debug("Duplicate user '{}' found in multiple groups. Groups: {}",
                                existing.getUserPrincipalName(), existing.getGroupIds());
                        return existing;
                    });
                }

            } catch (Exception e) {
                logger.error("Failed to fetch users from group '{}' [{}]: {}. Skipping.",
                        groupName, groupId, e.getMessage(), e);
            }
        }

        logger.info("Finished processing all groups. Total unique users: {}", aggregatedUsers.size());
        return aggregatedUsers;
    }

    // -----------------------------------------------------------------------
    // Phase 1: Resolve group display names → Object IDs
    // -----------------------------------------------------------------------

    /**
     * Resolves a list of group display names to their Azure AD Object IDs.
     *
     * <p>For each name, calls:
     * <pre>
     *   GET /v1.0/groups?$filter=displayName eq 'SM-APPLICATION-ADMIN'
     *                  &$select=id,displayName
     * </pre>
     * </p>
     *
     * <p>Groups that cannot be found are skipped with a warning log.
     * If a name matches multiple groups (rare), the first result is used.</p>
     *
     * @param groupNames list of display names from application.properties
     * @return ordered map of displayName → objectId for all successfully resolved groups
     */
    private Map<String, String> resolveGroupNamesToIds(List<String> groupNames) {
        logger.info("Resolving {} group name(s) to Object IDs...", groupNames.size());

        // LinkedHashMap preserves the order of groups as defined in config
        Map<String, String> resolved = new LinkedHashMap<>();

        for (String groupName : groupNames) {
            try {
                String objectId = resolveGroupNameToId(groupName);
                if (objectId != null) {
                    resolved.put(groupName, objectId);
                    logger.info("  Resolved: '{}' -> {}", groupName, objectId);
                } else {
                    logger.warn("  Group not found: '{}'. Check the display name and permissions.", groupName);
                }
            } catch (Exception e) {
                logger.error("  Failed to resolve group '{}': {}. Skipping.", groupName, e.getMessage(), e);
            }
        }

        logger.info("Resolution complete: {}/{} group(s) resolved successfully.",
                resolved.size(), groupNames.size());
        return resolved;
    }

    /**
     * Resolves a single group display name to its Object ID.
     *
     * <p>Uses {@code $filter=displayName eq 'name'} which requires the
     * {@code ConsistencyLevel: eventual} header (already set in HttpClientUtil).
     * The filter is case-insensitive on most Azure AD tenants.</p>
     *
     * @param groupName the exact display name of the group (e.g. "SM-APPLICATION-ADMIN")
     * @return the Object ID string, or {@code null} if not found
     */
    private String resolveGroupNameToId(String groupName) throws Exception {
        // URL-encode the group name to handle spaces, ampersands, etc.
        String encodedName = URLEncoder.encode("'" + groupName + "'", StandardCharsets.UTF_8);

        String url = config.getGraphApiBaseUrl()
                   + "/groups"
                   + "?$filter=displayName%20eq%20" + encodedName
                   + "&$select=id,displayName"
                   + "&$count=true";

        logger.debug("Resolving group name '{}' via: {}", groupName, url);

        String accessToken  = authService.getAccessToken();
        String responseJson = httpClient.get(url, accessToken);

        return parseGroupIdFromResponse(responseJson, groupName);
    }

    /**
     * Parses the group Object ID from the {@code /groups?$filter=...} response.
     *
     * <p>Expected JSON:
     * <pre>
     * {
     *   "value": [
     *     { "id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx", "displayName": "SM-APPLICATION-ADMIN" }
     *   ]
     * }
     * </pre>
     * </p>
     *
     * @return the {@code id} field of the first match, or {@code null} if the value array is empty
     */
    private String parseGroupIdFromResponse(String json, String groupName) throws Exception {
        JsonNode root = objectMapper.readTree(json);

        // Surface any Graph API error (e.g. missing Group.Read.All permission)
        if (root.has("error")) {
            String code    = root.path("error").path("code").asText();
            String message = root.path("error").path("message").asText();
            throw new RuntimeException(
                    "Graph API error while resolving group '" + groupName + "': [" + code + "] " + message);
        }

        JsonNode valueArray = root.path("value");

        if (!valueArray.isArray() || valueArray.isEmpty()) {
            // Group not found — return null so caller can log a warning and continue
            return null;
        }

        if (valueArray.size() > 1) {
            // Multiple groups with the same display name — warn and use the first
            logger.warn("Group name '{}' matched {} groups. Using the first result: id={}",
                    groupName, valueArray.size(), valueArray.get(0).path("id").asText());
        }

        String resolvedId = valueArray.get(0).path("id").asText();
        return resolvedId.isBlank() ? null : resolvedId;
    }

    // -----------------------------------------------------------------------
    // Phase 2: Paginated member fetch for a single group
    // -----------------------------------------------------------------------

    /**
     * Fetches ALL users from a single AD group, following pagination links.
     *
     * <p>The Graph API returns at most {@code $top} users per page. When there
     * are more results, the response includes an {@code @odata.nextLink} field
     * with the URL for the next page. This method iterates until no
     * {@code nextLink} is present.</p>
     *
     * @param groupId   the Azure AD Object ID of the group
     * @param groupName the human-readable name (used only for log messages)
     * @return list of all users in the group (may be 1000+)
     */
    private List<User> fetchAllUsersFromGroup(String groupId, String groupName) throws Exception {
        List<User> allUsers   = new ArrayList<>();
        String     nextUrl    = buildInitialGroupMembersUrl(groupId);
        int        pageNumber = 0;

        while (nextUrl != null) {
            pageNumber++;
            logger.debug("Group '{}' — fetching page {} [URL: {}]", groupName, pageNumber, nextUrl);

            String accessToken  = authService.getAccessToken();
            String responseJson = httpClient.get(nextUrl, accessToken);

            PageResult pageResult = parseMembersPage(responseJson, groupName);
            allUsers.addAll(pageResult.users);

            logger.info("Group '{}' — page {} fetched: {} user(s) (running total: {})",
                    groupName, pageNumber, pageResult.users.size(), allUsers.size());

            // null nextLink means this was the last page
            nextUrl = pageResult.nextLink;
        }

        logger.debug("Group '{}' — pagination complete. {} page(s), {} total user(s).",
                groupName, pageNumber, allUsers.size());
        return allUsers;
    }

    /**
     * Builds the URL for the first page of group members.
     *
     * <p>The type qualifier {@code /microsoft.graph.user} ensures only user objects
     * are returned — nested groups and service principals are excluded automatically.</p>
     */
    private String buildInitialGroupMembersUrl(String groupId) {
        return config.getGraphApiBaseUrl()
             + "/groups/" + groupId
             + "/members/microsoft.graph.user"
             + "?$select=" + SELECT_FIELDS
             + "&$top="    + config.getPageSize()
             + "&$count=true";
    }

    // -----------------------------------------------------------------------
    // JSON parsing helpers
    // -----------------------------------------------------------------------

    /**
     * Parses a single members-page response into a list of {@link User} objects
     * and the next-page URL.
     *
     * <p>Expected JSON structure:
     * <pre>
     * {
     *   "@odata.count"    : 1500,
     *   "@odata.nextLink" : "https://...",   // absent on last page
     *   "value": [
     *     { "id": "...", "displayName": "...", ... },
     *     ...
     *   ]
     * }
     * </pre>
     * </p>
     */
    private PageResult parseMembersPage(String json, String groupName) throws Exception {
        JsonNode root = objectMapper.readTree(json);

        // Surface Graph API errors (e.g. group not found, missing permissions)
        if (root.has("error")) {
            String code    = root.path("error").path("code").asText();
            String message = root.path("error").path("message").asText();
            throw new RuntimeException(
                    "Graph API error fetching members for '" + groupName + "': [" + code + "] " + message);
        }

        // Log total count if present (only on first page due to $count=true)
        if (root.has("@odata.count")) {
            logger.info("Group '{}' — total member count (from @odata.count): {}",
                    groupName, root.get("@odata.count").asLong());
        }

        List<User> users      = new ArrayList<>();
        JsonNode   valueArray = root.path("value");

        if (!valueArray.isArray()) {
            logger.warn("Group '{}' — 'value' field missing or not an array in response", groupName);
            return new PageResult(users, null);
        }

        for (JsonNode userNode : valueArray) {
            try {
                User user = objectMapper.treeToValue(userNode, User.class);

                if (user.getId() == null || user.getId().isBlank()) {
                    logger.warn("Skipping user entry with missing ID in group '{}'", groupName);
                    continue;
                }

                // Tag this user with the group name (not just ID) for readability in reports
                user.addGroupId(groupName);
                users.add(user);

            } catch (Exception e) {
                logger.error("Failed to parse user node in group '{}': {}. Node: {}",
                        groupName, e.getMessage(), userNode);
            }
        }

        // Extract next page URL — null signals last page
        String nextLink = null;
        JsonNode nextLinkNode = root.get("@odata.nextLink");
        if (nextLinkNode != null && !nextLinkNode.isNull()) {
            nextLink = nextLinkNode.asText();
        }

        return new PageResult(users, nextLink);
    }

    // -----------------------------------------------------------------------
    // Internal value object
    // -----------------------------------------------------------------------

    /** Holds the parsed users and next-page URL from a single Graph API page response. */
    private static class PageResult {
        final List<User> users;
        final String     nextLink;   // null on the last page

        PageResult(List<User> users, String nextLink) {
            this.users    = users;
            this.nextLink = nextLink;
        }
    }
}
