package com.kalai.graphapi.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kalai.graphapi.config.GraphApiConfig;
import com.kalai.graphapi.model.User;
import com.kalai.graphapi.util.HttpClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Core service for fetching user data from Microsoft Graph API.
 *
 * <p>Key capabilities:</p>
 * <ul>
 *   <li><strong>Multiple groups:</strong> iterates over all group IDs in config</li>
 *   <li><strong>Pagination:</strong> follows {@code @odata.nextLink} until exhausted,
 *       handling 1000+ users per group transparently</li>
 *   <li><strong>Deduplication:</strong> uses a {@link LinkedHashMap} keyed by the
 *       user's Azure AD Object ID; if the same user appears in multiple groups
 *       their {@code groupIds} set is merged</li>
 *   <li><strong>Members-only endpoint:</strong> calls
 *       {@code /groups/{id}/members/microsoft.graph.user} which filters out
 *       nested groups and service principals automatically</li>
 * </ul>
 *
 * <p>Graph API endpoint used:
 * <pre>
 *   GET /v1.0/groups/{groupId}/members/microsoft.graph.user
 *       ?$select=id,displayName,userPrincipalName,mail,givenName,surname,
 *                jobTitle,department,officeLocation,companyName,
 *                mobilePhone,businessPhones,accountEnabled,createdDateTime
 *       &$top={pageSize}
 *       &$count=true
 * </pre>
 * </p>
 */
public class GraphService {

    private static final Logger logger = LogManager.getLogger(GraphService.class);

    /**
     * The set of user fields to retrieve from Graph API.
     * Only request what you need to keep responses lean and fast.
     */
    private static final String SELECT_FIELDS =
            "id,displayName,userPrincipalName,mail,givenName,surname," +
            "jobTitle,department,officeLocation,companyName," +
            "mobilePhone,businessPhones,accountEnabled,createdDateTime";

    private final GraphApiConfig config;
    private final HttpClientUtil httpClient;
    private final AuthService    authService;
    private final ObjectMapper   objectMapper;

    /**
     * @param config      loaded application configuration
     * @param httpClient  shared HTTP client utility
     * @param authService service used to obtain (and refresh) the access token
     */
    public GraphService(GraphApiConfig config,
                        HttpClientUtil httpClient,
                        AuthService    authService) {
        this.config       = config;
        this.httpClient   = httpClient;
        this.authService  = authService;
        this.objectMapper = new ObjectMapper();
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Fetches all users from every AD group listed in the configuration.
     *
     * <p>Users that appear in more than one group are represented by a single
     * {@link User} entry; their {@code groupIds} set will contain all the groups
     * they belong to.</p>
     *
     * @return a {@link Map} of Azure AD Object ID → {@link User},
     *         preserving insertion order (via {@link LinkedHashMap})
     */
    public Map<String, User> fetchUsersFromAllGroups() {
        List<String> groupIds = config.getGroupIds();

        logger.info("Starting user fetch for {} AD group(s): {}", groupIds.size(), groupIds);

        /*
         * LinkedHashMap preserves insertion order so logs/output are predictable.
         * Key = Azure AD user Object ID (GUID) — guarantees uniqueness.
         */
        Map<String, User> aggregatedUsers = new LinkedHashMap<>();

        int groupIndex = 0;
        for (String groupId : groupIds) {
            groupIndex++;
            logger.info("--- Processing group {}/{}: {} ---", groupIndex, groupIds.size(), groupId);

            try {
                List<User> groupUsers = fetchAllUsersFromGroup(groupId);

                logger.info("Group '{}': fetched {} user(s)", groupId, groupUsers.size());

                // Merge into the aggregate map — deduplicating by user Object ID
                for (User user : groupUsers) {
                    aggregatedUsers.merge(user.getId(), user, (existing, incoming) -> {
                        // Same user in multiple groups: merge group membership sets
                        existing.mergeGroupsFrom(incoming);
                        logger.debug("Duplicate user '{}' merged across groups. Now in groups: {}",
                                existing.getUserPrincipalName(), existing.getGroupIds());
                        return existing;
                    });
                }

            } catch (Exception e) {
                // Log the error but continue processing remaining groups
                logger.error("Failed to fetch users from group '{}': {}. Skipping group.",
                        groupId, e.getMessage(), e);
            }
        }

        logger.info("Finished processing all groups. Total unique users: {}", aggregatedUsers.size());
        return aggregatedUsers;
    }

    // -----------------------------------------------------------------------
    // Internal: paginated fetch for a single group
    // -----------------------------------------------------------------------

    /**
     * Fetches ALL users from a single AD group, following pagination links.
     *
     * <p>The Graph API returns at most {@code $top} users per page. When there
     * are more results, the response includes an {@code @odata.nextLink} field
     * with the URL for the next page. This method iterates until no
     * {@code nextLink} is present.</p>
     *
     * @param groupId the Azure AD Object ID of the group
     * @return list of all users in the group (may be 1000+)
     */
    private List<User> fetchAllUsersFromGroup(String groupId) throws Exception {
        List<User> allUsers  = new ArrayList<>();
        String     nextUrl   = buildInitialGroupUrl(groupId);
        int        pageNumber = 0;

        while (nextUrl != null) {
            pageNumber++;
            logger.debug("Group '{}' — fetching page {} [URL: {}]", groupId, pageNumber, nextUrl);

            // Obtain a valid token (refreshed automatically if near expiry)
            String accessToken  = authService.getAccessToken();
            String responseJson = httpClient.get(nextUrl, accessToken);

            // Parse the page response
            PageResult pageResult = parsePage(responseJson, groupId);
            allUsers.addAll(pageResult.users);

            logger.info("Group '{}' — page {} fetched: {} user(s) (running total: {})",
                    groupId, pageNumber, pageResult.users.size(), allUsers.size());

            // Advance to next page (null = last page)
            nextUrl = pageResult.nextLink;
        }

        logger.debug("Group '{}' — pagination complete. {} page(s), {} total user(s).",
                groupId, pageNumber, allUsers.size());
        return allUsers;
    }

    /**
     * Builds the URL for the first page of group members.
     *
     * <p>Endpoint: {@code /groups/{groupId}/members/microsoft.graph.user}
     * — the type qualifier {@code /microsoft.graph.user} ensures only user objects
     * are returned (groups and service principals are excluded automatically).</p>
     *
     * <p>Query parameters:
     * <ul>
     *   <li>{@code $select} — request only the fields we need</li>
     *   <li>{@code $top}    — number of records per page (max 999 for this endpoint)</li>
     *   <li>{@code $count}  — ask for a total count (requires ConsistencyLevel: eventual)</li>
     * </ul>
     * </p>
     */
    private String buildInitialGroupUrl(String groupId) {
        return config.getGraphApiBaseUrl()
             + "/groups/" + groupId
             + "/members/microsoft.graph.user"
             + "?$select=" + SELECT_FIELDS
             + "&$top="    + config.getPageSize()
             + "&$count=true";
    }

    // -----------------------------------------------------------------------
    // Internal: JSON parsing
    // -----------------------------------------------------------------------

    /**
     * Parses a single Graph API page response.
     *
     * <p>Expected JSON structure:
     * <pre>
     * {
     *   "@odata.context"  : "...",
     *   "@odata.count"    : 1500,          // optional, present only if $count=true
     *   "@odata.nextLink" : "https://...", // absent on last page
     *   "value": [
     *     { "id": "...", "displayName": "...", ... },
     *     ...
     *   ]
     * }
     * </pre>
     * </p>
     *
     * @param json    raw JSON string from Graph API
     * @param groupId the group being processed (used for logging and user tagging)
     * @return a {@link PageResult} containing the user list and the next-page URL
     */
    private PageResult parsePage(String json, String groupId) throws Exception {
        JsonNode root = objectMapper.readTree(json);

        // Detect Graph API error responses (e.g. group not found, missing permissions)
        if (root.has("error")) {
            JsonNode errorNode = root.get("error");
            String code    = errorNode.path("code").asText();
            String message = errorNode.path("message").asText();
            throw new RuntimeException(
                    "Graph API error for group '" + groupId + "': [" + code + "] " + message);
        }

        // Log total count if available (only on first page due to $count=true)
        if (root.has("@odata.count")) {
            logger.info("Group '{}' total member count (from @odata.count): {}",
                    groupId, root.get("@odata.count").asLong());
        }

        // Extract the "value" array of user objects
        List<User> users = new ArrayList<>();
        JsonNode valueArray = root.path("value");

        if (!valueArray.isArray()) {
            logger.warn("Group '{}' — 'value' field missing or not an array in response", groupId);
            return new PageResult(users, null);
        }

        for (JsonNode userNode : valueArray) {
            try {
                // Deserialise JSON node into User POJO
                User user = objectMapper.treeToValue(userNode, User.class);

                // Safety check: skip entries without an ID (should not happen, but defensive)
                if (user.getId() == null || user.getId().isBlank()) {
                    logger.warn("Skipping user entry with missing ID in group '{}'", groupId);
                    continue;
                }

                // Record which group this user came from
                user.addGroupId(groupId);
                users.add(user);

            } catch (Exception e) {
                logger.error("Failed to parse user node in group '{}': {}. Node: {}",
                        groupId, e.getMessage(), userNode);
                // Continue processing remaining users in the page
            }
        }

        // Extract next page URL (null if this is the last page)
        String nextLink = null;
        JsonNode nextLinkNode = root.get("@odata.nextLink");
        if (nextLinkNode != null && !nextLinkNode.isNull()) {
            nextLink = nextLinkNode.asText();
        }

        return new PageResult(users, nextLink);
    }

    // -----------------------------------------------------------------------
    // Internal value object for page results
    // -----------------------------------------------------------------------

    /**
     * Simple container holding the users from one page and the URL for the next page.
     */
    private static class PageResult {
        final List<User> users;
        final String     nextLink;   // null on the last page

        PageResult(List<User> users, String nextLink) {
            this.users    = users;
            this.nextLink = nextLink;
        }
    }
}
