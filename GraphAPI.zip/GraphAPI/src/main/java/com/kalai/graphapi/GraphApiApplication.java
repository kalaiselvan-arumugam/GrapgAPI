package com.kalai.graphapi;

import com.kalai.graphapi.config.GraphClientConfig;
import com.kalai.graphapi.model.UserDetail;
import com.kalai.graphapi.service.GraphUserService;
import com.kalai.graphapi.util.AppProperties;
import com.kalai.graphapi.util.ResultPrinter;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * <h2>GraphAPI — Microsoft Graph AD Group Member Fetcher</h2>
 *
 * <p>Entry point for the application. Orchestrates the following steps:
 * <ol>
 *   <li>Load configuration from {@code application.properties}</li>
 *   <li>Build an authenticated {@link GraphServiceClient} using the
 *       OAuth2 Client Credentials (Application) flow</li>
 *   <li>Fetch all user members from every configured AD group, with
 *       automatic pagination for groups larger than 999 members</li>
 *   <li>Deduplicate users that appear in multiple groups</li>
 *   <li>Print a structured JSON summary and a group membership table</li>
 * </ol>
 *
 * <h3>How to run</h3>
 * <pre>
 *   # Build a fat-jar
 *   mvn clean package -DskipTests
 *
 *   # Run
 *   java -jar target/GraphAPI-1.0.0.jar
 * </pre>
 *
 * <h3>Configuration</h3>
 * Set the following in {@code src/main/resources/application.properties}
 * before running:
 * <ul>
 *   <li>{@code azure.tenant.id}      — Azure AD Tenant (Directory) ID</li>
 *   <li>{@code azure.client.id}      — App Registration Client ID</li>
 *   <li>{@code azure.client.secret}  — App Registration Client Secret</li>
 *   <li>{@code azure.ad.group.ids}   — Comma-separated AD group Object IDs</li>
 * </ul>
 */
public class GraphApiApplication {

    private static final Logger log = LogManager.getLogger(GraphApiApplication.class);

    // =========================================================================
    // Main
    // =========================================================================

    /**
     * Application entry point.
     *
     * @param args command-line arguments (not used; all config via properties file)
     */
    public static void main(String[] args) {

        log.info("╔══════════════════════════════════════════════════════╗");
        log.info("║         GraphAPI — AD Group Member Fetcher           ║");
        log.info("╚══════════════════════════════════════════════════════╝");

        try {
            // ------------------------------------------------------------------
            // Step 1: Build the authenticated Graph client
            // ------------------------------------------------------------------
            GraphServiceClient graphClient = GraphClientConfig.buildGraphClient();

            // ------------------------------------------------------------------
            // Step 2: Fetch users from all configured groups
            // ------------------------------------------------------------------
            GraphUserService userService = new GraphUserService(graphClient);
            Map<String, UserDetail> users = userService.fetchUsersFromAllGroups();

            // ------------------------------------------------------------------
            // Step 3: Print results
            // ------------------------------------------------------------------
            ResultPrinter.printGroupSummary(users);
            ResultPrinter.printResults(users, AppProperties.isPrettyPrint());

            log.info("GraphAPI completed successfully.");

        } catch (IllegalStateException e) {
            // Configuration / validation errors (missing properties, etc.)
            log.error("Configuration error: {}", e.getMessage());
            log.error("Please check your application.properties and ensure all " +
                      "mandatory fields are set correctly.");
            System.exit(1);

        } catch (Exception e) {
            // Unexpected runtime errors
            log.error("Unexpected error during execution: {}", e.getMessage(), e);
            System.exit(2);
        }
    }
}
