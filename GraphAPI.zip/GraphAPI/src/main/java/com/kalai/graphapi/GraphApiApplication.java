package com.kalai.graphapi;

import com.kalai.graphapi.config.GraphClientConfig;
import com.kalai.graphapi.model.UserDetail;
import com.kalai.graphapi.service.GraphUserService;
import com.kalai.graphapi.util.AppProperties;
import com.kalai.graphapi.util.ResultPrinter;
import com.kalai.graphapi.util.SslTrustFix;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * <h2>GraphAPI — Microsoft Graph AD Group Member Fetcher</h2>
 *
 * <p>Entry point. Runs the following steps in order:
 * <ol>
 *   <li><strong>SSL trust fix</strong> — installs Microsoft's intermediate CA
 *       into the JVM's in-memory truststore to prevent PKIX errors when
 *       connecting to {@code login.microsoftonline.com}.</li>
 *   <li><strong>Authenticate</strong> — builds a {@link GraphServiceClient}
 *       using the client ID, tenant ID, and client secret from
 *       {@code application.properties}.</li>
 *   <li><strong>Fetch members</strong> — retrieves all users from every
 *       configured AD group, with automatic pagination (1 000+ users) and
 *       deduplication across groups.</li>
 *   <li><strong>Print results</strong> — outputs a JSON summary and a
 *       per-group membership table to the console.</li>
 * </ol>
 *
 * <h3>Quick start</h3>
 * <pre>
 *   # 1. Get the Microsoft intermediate CA certificate (one-time)
 *   openssl s_client -connect login.microsoftonline.com:443 -showcerts \
 *     &lt;/dev/null 2&gt;/dev/null \
 *     | awk '/BEGIN CERT/{f=1} f{print} /END CERT/{f=0}' \
 *     | awk 'BEGIN{n=0} /BEGIN CERT/{n++} n==2{print}' \
 *     &gt; src/main/resources/certs/ms-azure-tls-ca.pem
 *
 *   # 2. Fill in application.properties
 *   #    azure.tenant.id, azure.client.id, azure.client.secret, azure.ad.group.ids
 *
 *   # 3. Build and run
 *   mvn clean package -DskipTests
 *   java -jar target/GraphAPI-1.0.0.jar
 * </pre>
 */
public class GraphApiApplication {

    private static final Logger log = LogManager.getLogger(GraphApiApplication.class);

    public static void main(String[] args) {

        log.info("╔══════════════════════════════════════════════════════╗");
        log.info("║         GraphAPI — AD Group Member Fetcher           ║");
        log.info("╚══════════════════════════════════════════════════════╝");

        try {
            // ------------------------------------------------------------------
            // Step 1: Fix PKIX — must run BEFORE any HTTPS/SDK call is made.
            //
            // Loads Microsoft's intermediate CA cert from the classpath and
            // merges it with the JVM's default truststore in memory.
            // The cacerts file on disk is never modified.
            // ------------------------------------------------------------------
            SslTrustFix.applyIfEnabled();

            // ------------------------------------------------------------------
            // Step 2: Build the authenticated Graph client
            //         (Client Credentials flow — tenant ID + client ID + secret)
            // ------------------------------------------------------------------
            GraphServiceClient graphClient = GraphClientConfig.buildGraphClient();

            // ------------------------------------------------------------------
            // Step 3: Fetch users from all configured AD groups
            // ------------------------------------------------------------------
            GraphUserService userService = new GraphUserService(graphClient);
            Map<String, UserDetail> users = userService.fetchUsersFromAllGroups();

            // ------------------------------------------------------------------
            // Step 4: Print results
            // ------------------------------------------------------------------
            ResultPrinter.printGroupSummary(users);
            ResultPrinter.printResults(users, AppProperties.isPrettyPrint());

            log.info("GraphAPI completed successfully.");

        } catch (IllegalStateException e) {
            // Configuration / validation errors — missing properties etc.
            log.error("Configuration error: {}", e.getMessage());
            log.error("Check application.properties and ensure all mandatory " +
                      "fields (azure.tenant.id, azure.client.id, azure.client.secret, " +
                      "azure.ad.group.ids) are set.");
            System.exit(1);

        } catch (Exception e) {
            log.error("Unexpected error: {}", e.getMessage(), e);
            System.exit(2);
        }
    }
}
