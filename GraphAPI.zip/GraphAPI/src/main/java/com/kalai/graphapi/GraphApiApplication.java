package com.kalai.graphapi;

import com.kalai.graphapi.config.GraphApiConfig;
import com.kalai.graphapi.model.User;
import com.kalai.graphapi.service.AuthService;
import com.kalai.graphapi.service.GraphService;
import com.kalai.graphapi.util.HttpClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * Application entry point for the Microsoft Graph API AD Group User Fetcher.
 *
 * <p>Startup sequence:</p>
 * <ol>
 *   <li>Load {@code application.properties} via {@link GraphApiConfig}</li>
 *   <li>Build a shared {@link HttpClientUtil} with configured timeouts</li>
 *   <li>Authenticate with Azure AD using client credentials flow ({@link AuthService})</li>
 *   <li>Fetch users from all configured AD groups with pagination ({@link GraphService})</li>
 *   <li>Print a deduplicated summary to the console via Log4j2</li>
 * </ol>
 *
 * <p><strong>Build and run:</strong></p>
 * <pre>
 *   mvn clean package
 *   java -jar target/GraphAPI-1.0.0.jar
 * </pre>
 *
 * <p><strong>Required Azure AD app permissions (Application type — not Delegated):</strong></p>
 * <ul>
 *   <li>{@code GroupMember.Read.All} — list members of any group</li>
 *   <li>{@code User.Read.All}        — read full user profiles</li>
 * </ul>
 * Grant admin consent for these in the Azure Portal under
 * App Registrations → Your App → API Permissions.
 */
public class GraphApiApplication {

    private static final Logger logger = LogManager.getLogger(GraphApiApplication.class);

    public static void main(String[] args) {
        logger.info("╔══════════════════════════════════════════════════╗");
        logger.info("║    Microsoft Graph API - AD Group User Fetcher   ║");
        logger.info("╚══════════════════════════════════════════════════╝");

        try {
            // ----------------------------------------------------------
            // Step 1: Load configuration from application.properties
            // ----------------------------------------------------------
            GraphApiConfig config = GraphApiConfig.load();

            // ----------------------------------------------------------
            // Step 2: Initialise the shared HTTP client
            //         (single instance — thread-safe, connection-pooled)
            // ----------------------------------------------------------
            HttpClientUtil httpClient = new HttpClientUtil(config);

            // ----------------------------------------------------------
            // Step 3: Initialise services
            // ----------------------------------------------------------
            AuthService  authService  = new AuthService(config, httpClient);
            GraphService graphService = new GraphService(config, httpClient, authService);

            // ----------------------------------------------------------
            // Step 4: Pre-flight authentication check
            //         Fail fast here rather than mid-way through group fetch
            // ----------------------------------------------------------
            logger.info("Authenticating with Azure AD...");
            authService.getAccessToken();   // throws if credentials are wrong
            logger.info("Authentication successful ✓");

            // ----------------------------------------------------------
            // Step 5: Fetch users from all configured AD groups
            //         Handles pagination (1000+ users) and deduplication
            // ----------------------------------------------------------
            Map<String, User> allUsers = graphService.fetchUsersFromAllGroups();

            // ----------------------------------------------------------
            // Step 6: Print the summary report
            // ----------------------------------------------------------
            printSummaryReport(allUsers, config);

        } catch (Exception e) {
            logger.error("Application terminated with an error: {}", e.getMessage(), e);
            System.exit(1);
        }
    }

    // -----------------------------------------------------------------------
    // Report
    // -----------------------------------------------------------------------

    /**
     * Logs a structured summary of all unique users found across all groups.
     *
     * @param allUsers the deduplicated user map (Object ID → User)
     * @param config   configuration (used to list the group IDs processed)
     */
    private static void printSummaryReport(Map<String, User> allUsers, GraphApiConfig config) {
        logger.info("");
        logger.info("╔══════════════════════════════════════════════════╗");
        logger.info("║                  SUMMARY REPORT                 ║");
        logger.info("╚══════════════════════════════════════════════════╝");
        logger.info("Groups processed : {}", config.getGroupIds().size());
        logger.info("Total unique users: {}", allUsers.size());
        logger.info("");

        if (allUsers.isEmpty()) {
            logger.warn("No users found. Verify the group IDs and app permissions.");
            return;
        }

        // Column-aligned header
        logger.info("  {:<45} {:<40} {:<35} {:<20} {:<20} {}",
                "Display Name", "UPN", "Email", "Job Title", "Department", "Groups");
        logger.info("  " + "-".repeat(210));

        for (User user : allUsers.values()) {
            logger.info("  {:<45} {:<40} {:<35} {:<20} {:<20} {}",
                    nullSafe(user.getDisplayName()),
                    nullSafe(user.getUserPrincipalName()),
                    nullSafe(user.getMail()),
                    nullSafe(user.getJobTitle()),
                    nullSafe(user.getDepartment()),
                    user.getGroupIds());
        }

        logger.info("");

        // Highlight users present in multiple groups
        long multiGroupCount = allUsers.values().stream()
                .filter(u -> u.getGroupIds().size() > 1)
                .count();
        if (multiGroupCount > 0) {
            logger.info("Users found in multiple groups: {}", multiGroupCount);
            allUsers.values().stream()
                    .filter(u -> u.getGroupIds().size() > 1)
                    .forEach(u -> logger.info("  ↳ {} ({}) → groups: {}",
                            u.getDisplayName(), u.getUserPrincipalName(), u.getGroupIds()));
        }

        logger.info("");
        logger.info("Fetch complete.");
    }

    /** Returns the value, or {@code "(null)"} if the value is null or blank. */
    private static String nullSafe(String value) {
        return (value == null || value.isBlank()) ? "(null)" : value;
    }
}
