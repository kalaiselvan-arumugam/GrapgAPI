package com.kalai.graphapi.config;

import com.azure.core.credential.TokenCredential;
import com.azure.identity.ClientCertificateCredentialBuilder;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.kalai.graphapi.util.AppProperties;
import com.kalai.graphapi.util.AppProperties.AuthMode;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;

/**
 * Factory class that builds an authenticated {@link GraphServiceClient} using
 * the OAuth2 <em>Client Credentials</em> flow (Application access).
 *
 * <h3>Supported authentication modes  (set {@code azure.auth.mode})</h3>
 * <ul>
 *   <li><strong>SECRET</strong> — client ID + client secret.  Simplest to set
 *       up; fine for development and testing.</li>
 *   <li><strong>PEM</strong> — a {@code .pem} file that contains <em>both</em>
 *       the private key block ({@code -----BEGIN PRIVATE KEY-----}) and the
 *       X.509 certificate block ({@code -----BEGIN CERTIFICATE-----}).
 *       If the two are in separate files, concatenate them first:
 *       {@code cat private.key cert.crt > combined.pem}</li>
 *   <li><strong>PFX</strong> — a {@code .pfx}/{@code .p12} PKCS#12 bundle,
 *       optionally protected with a password.</li>
 * </ul>
 *
 * <h3>Azure AD App Registration permissions required (Application type)</h3>
 * <ul>
 *   <li>{@code Group.Read.All}</li>
 *   <li>{@code User.Read.All}</li>
 * </ul>
 * Both must have admin consent granted in the Azure portal.
 */
public class GraphClientConfig {

    private static final Logger log = LogManager.getLogger(GraphClientConfig.class);

    /**
     * The {@code .default} scope requests a token scoped to all Application
     * permissions granted to this App Registration.
     */
    private static final String GRAPH_SCOPE = "https://graph.microsoft.com/.default";

    private GraphClientConfig() {}

    // =========================================================================
    // Public factory
    // =========================================================================

    /**
     * Builds and returns a ready-to-use {@link GraphServiceClient}.
     *
     * <p>The credential type is determined by {@code azure.auth.mode} in
     * {@code application.properties}.  The SDK automatically acquires,
     * caches, and refreshes the bearer token as needed.
     *
     * @return authenticated {@link GraphServiceClient}
     * @throws IllegalStateException if any required property is missing or
     *                               a certificate file cannot be loaded
     */
    public static GraphServiceClient buildGraphClient() {

        AuthMode mode     = AppProperties.getAuthMode();
        String   tenantId = AppProperties.getTenantId();
        String   clientId = AppProperties.getClientId();

        log.info("Initialising GraphServiceClient [mode={}]", mode);
        log.debug("Tenant ID : {}", tenantId);
        log.debug("Client ID : {}", clientId);

        TokenCredential credential = buildCredential(mode, tenantId, clientId);

        GraphServiceClient client = new GraphServiceClient(credential, GRAPH_SCOPE);

        log.info("GraphServiceClient ready — endpoint: {}", AppProperties.getGraphEndpoint());
        return client;
    }

    // =========================================================================
    // Credential builders
    // =========================================================================

    /**
     * Dispatches to the correct credential builder based on {@code mode}.
     */
    private static TokenCredential buildCredential(
            AuthMode mode, String tenantId, String clientId) {

        return switch (mode) {

            case SECRET -> {
                log.info("Auth: Client Secret");
                log.debug("Secret: [REDACTED]");
                yield new ClientSecretCredentialBuilder()
                        .tenantId(tenantId)
                        .clientId(clientId)
                        .clientSecret(AppProperties.getClientSecret())
                        .build();
            }

            case PEM -> {
                Path path = AppProperties.getCertPath();
                log.info("Auth: PEM certificate [{}]", path);
                /*
                 * pemCertificate() reads the PEM file directly.
                 * The file must contain both the PRIVATE KEY block and the
                 * CERTIFICATE block.
                 */
                yield new ClientCertificateCredentialBuilder()
                        .tenantId(tenantId)
                        .clientId(clientId)
                        .pemCertificate(path.toString())
                        .build();
            }

            case PFX -> {
                Path   path     = AppProperties.getCertPath();
                String password = AppProperties.getCertPfxPassword();
                log.info("Auth: PFX certificate [{}] | password-protected: {}",
                         path, password != null);
                /*
                 * pfxCertificate() accepts the file path and an optional password.
                 * Pass null when the bundle has no password.
                 */
                yield new ClientCertificateCredentialBuilder()
                        .tenantId(tenantId)
                        .clientId(clientId)
                        .pfxCertificate(path.toString(), password)
                        .build();
            }
        };
    }
}
