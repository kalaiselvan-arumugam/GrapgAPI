package com.kalai.graphapi.config;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.kalai.graphapi.util.AppProperties;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Factory / configuration class that builds a fully authenticated
 * {@link GraphServiceClient} using the OAuth2 <em>Client Credentials</em>
 * flow (Application access — no delegated/user permissions required).
 *
 * <h3>Required Azure AD App Registration permissions (Application type)</h3>
 * <ul>
 *   <li>{@code Group.Read.All}  — read group metadata and memberships</li>
 *   <li>{@code User.Read.All}   — read full user profiles</li>
 * </ul>
 * Both permissions must be granted admin consent in the Azure portal.
 *
 * <h3>Credential flow</h3>
 * <pre>
 *   App  →  Azure AD /token endpoint  →  Bearer token
 *        ← access_token (scope: https://graph.microsoft.com/.default)
 *   App  →  Graph API  (Authorization: Bearer &lt;token&gt;)
 * </pre>
 */
public class GraphClientConfig {

    private static final Logger log = LogManager.getLogger(GraphClientConfig.class);

    /**
     * The {@code .default} scope instructs Azure AD to issue a token with all
     * Application permissions that have been granted to this registration.
     */
    private static final String GRAPH_DEFAULT_SCOPE = "https://graph.microsoft.com/.default";

    /** Private constructor — this is a pure factory class. */
    private GraphClientConfig() {}

    // =========================================================================
    // Factory method
    // =========================================================================

    /**
     * Constructs and returns a ready-to-use {@link GraphServiceClient}.
     *
     * <p>The client uses {@link ClientSecretCredential} which automatically
     * acquires and caches the bearer token, refreshing it before expiry.
     *
     * @return authenticated {@link GraphServiceClient}
     * @throws IllegalStateException if the credentials in
     *         {@code application.properties} are missing
     */
    public static GraphServiceClient buildGraphClient() {

        log.info("Initialising Microsoft Graph client (Application / client-credentials flow)");

        // ------------------------------------------------------------------
        // 1. Read credentials from application.properties
        // ------------------------------------------------------------------
        String tenantId     = AppProperties.getTenantId();
        String clientId     = AppProperties.getClientId();
        String clientSecret = AppProperties.getClientSecret();

        log.debug("Tenant ID  : {}", tenantId);
        log.debug("Client ID  : {}", clientId);
        log.debug("Secret     : [REDACTED]");   // never log the actual secret

        // ------------------------------------------------------------------
        // 2. Build Azure Identity credential
        //    ClientSecretCredential → POST /token with client_id + client_secret
        // ------------------------------------------------------------------
        ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                .tenantId(tenantId)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .build();

        log.debug("ClientSecretCredential built successfully");

        // ------------------------------------------------------------------
        // 3. Wrap the credential in the Graph SDK client
        //    The SDK handles token acquisition, caching, and auto-refresh.
        // ------------------------------------------------------------------
        GraphServiceClient graphClient = new GraphServiceClient(
                credential,
                GRAPH_DEFAULT_SCOPE
        );

        log.info("GraphServiceClient initialised — endpoint: {}",
                 AppProperties.getGraphEndpoint());

        return graphClient;
    }
}
