package com.kalai.graphapi.config;

import com.azure.identity.ClientSecretCredentialBuilder;
import com.kalai.graphapi.util.AppProperties;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Factory class that builds an authenticated {@link GraphServiceClient} using
 * the OAuth2 <em>Client Credentials</em> (Application) flow with a
 * <strong>client secret</strong>.
 *
 * <h3>Credential flow</h3>
 * <pre>
 *   App  →  POST /&lt;tenantId&gt;/oauth2/v2.0/token
 *               grant_type=client_credentials
 *               client_id=&lt;clientId&gt;
 *               client_secret=&lt;secret&gt;
 *               scope=https://graph.microsoft.com/.default
 *        ←  access_token  (valid ~1 hour, auto-refreshed by the SDK)
 *   App  →  Graph API  (Authorization: Bearer &lt;token&gt;)
 * </pre>
 *
 * <h3>Required Azure AD App Registration permissions (Application type)</h3>
 * <ul>
 *   <li>{@code Group.Read.All}  — read group metadata and member lists</li>
 *   <li>{@code User.Read.All}   — read full user profiles</li>
 * </ul>
 * Both permissions must have <em>admin consent</em> granted in the Azure portal.
 */
public class GraphClientConfig {

    private static final Logger log = LogManager.getLogger(GraphClientConfig.class);

    /**
     * Requests a token covering all Application permissions granted to this
     * App Registration (the ".default" scope pattern).
     */
    private static final String GRAPH_SCOPE = "https://graph.microsoft.com/.default";

    private GraphClientConfig() {}

    // =========================================================================
    // Public factory
    // =========================================================================

    /**
     * Builds and returns a ready-to-use {@link GraphServiceClient} authenticated
     * with the client ID, tenant ID, and client secret from
     * {@code application.properties}.
     *
     * <p>The SDK automatically acquires, caches, and refreshes the bearer token
     * before it expires — no manual token management is needed.
     *
     * @return authenticated {@link GraphServiceClient}
     * @throws IllegalStateException if any required property is missing
     */
    public static GraphServiceClient buildGraphClient() {

        String tenantId = AppProperties.getTenantId();
        String clientId = AppProperties.getClientId();

        log.info("Initialising GraphServiceClient [tenantId={}, clientId={}]",
                 tenantId, clientId);
        log.debug("Client secret: [REDACTED]");  // never log the actual secret

        GraphServiceClient client = new GraphServiceClient(
                new ClientSecretCredentialBuilder()
                        .tenantId(tenantId)
                        .clientId(clientId)
                        .clientSecret(AppProperties.getClientSecret())
                        .build(),
                GRAPH_SCOPE
        );

        log.info("GraphServiceClient ready — endpoint: {}", AppProperties.getGraphEndpoint());
        return client;
    }
}
