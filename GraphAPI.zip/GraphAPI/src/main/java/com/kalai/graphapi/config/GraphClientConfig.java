package com.kalai.graphapi.config;

import com.azure.identity.ClientCertificateCredential;
import com.azure.identity.ClientCertificateCredentialBuilder;
import com.kalai.graphapi.util.AppProperties;
import com.kalai.graphapi.util.AppProperties.CertType;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;

/**
 * Factory class that builds a fully authenticated {@link GraphServiceClient}
 * using the OAuth2 <em>Client Credentials</em> flow with
 * <strong>certificate-based authentication</strong>.
 *
 * <h3>Supported certificate formats</h3>
 * <ul>
 *   <li><strong>JKS</strong> — Java KeyStore ({@code .jks}).  The SDK does not
 *       natively speak JKS, so this class extracts the private key and
 *       certificate chain from the store and converts them to an in-memory
 *       PKCS#12 stream that the Azure Identity SDK can consume directly.
 *       No temporary files are written to disk.</li>
 *   <li><strong>PEM</strong> — a {@code .pem} file containing both the private
 *       key block and the X.509 certificate block.</li>
 *   <li><strong>PFX</strong> — a {@code .pfx} / {@code .p12} PKCS#12 bundle,
 *       optionally password-protected.</li>
 * </ul>
 *
 * <h3>JKS → PKCS#12 conversion (in-memory)</h3>
 * <pre>
 *   KeyStore jks = KeyStore.getInstance("JKS")
 *   jks.load(FileInputStream, storePassword)
 *   ─── extract alias → PrivateKey + Certificate[]
 *   KeyStore pkcs12 = KeyStore.getInstance("PKCS12")
 *   pkcs12.setKeyEntry(alias, privateKey, tempPassword, certChain)
 *   pkcs12.store(ByteArrayOutputStream, tempPassword)
 *   ─── pass ByteArrayInputStream to ClientCertificateCredentialBuilder
 * </pre>
 * The intermediate PKCS#12 bytes exist only in heap memory and are
 * eligible for GC once the credential object is built.
 *
 * <h3>Azure AD App Registration permissions (Application type)</h3>
 * <ul>
 *   <li>{@code Group.Read.All}</li>
 *   <li>{@code User.Read.All}</li>
 * </ul>
 */
public class GraphClientConfig {

    private static final Logger log = LogManager.getLogger(GraphClientConfig.class);

    private static final String GRAPH_DEFAULT_SCOPE = "https://graph.microsoft.com/.default";

    /**
     * Temporary password used only for the in-memory PKCS#12 store during JKS
     * conversion. It is never persisted or transmitted.
     */
    private static final char[] TEMP_PKCS12_PASSWORD = "temp-in-memory".toCharArray();

    private GraphClientConfig() {}

    // =========================================================================
    // Factory method
    // =========================================================================

    /**
     * Builds and returns a ready-to-use {@link GraphServiceClient} authenticated
     * via the certificate specified in {@code application.properties}.
     *
     * @return authenticated {@link GraphServiceClient}
     * @throws IllegalStateException if configuration is invalid or the
     *                               certificate file cannot be loaded
     */
    public static GraphServiceClient buildGraphClient() {

        log.info("Initialising Microsoft Graph client (Application / certificate flow)");

        String   tenantId = AppProperties.getTenantId();
        String   clientId = AppProperties.getClientId();
        CertType certType = AppProperties.getCertType();
        Path     certPath = AppProperties.getCertPath();

        log.debug("Tenant ID  : {}", tenantId);
        log.debug("Client ID  : {}", clientId);
        log.debug("Cert type  : {}", certType);
        log.debug("Cert path  : {}", certPath);

        ClientCertificateCredential credential =
                buildCertificateCredential(tenantId, clientId, certType, certPath);

        log.debug("ClientCertificateCredential built successfully ({})", certType);

        GraphServiceClient graphClient = new GraphServiceClient(
                credential, GRAPH_DEFAULT_SCOPE);

        log.info("GraphServiceClient initialised — endpoint: {}",
                 AppProperties.getGraphEndpoint());

        return graphClient;
    }

    // =========================================================================
    // Credential builders
    // =========================================================================

    /**
     * Dispatches to the appropriate credential-building strategy based on
     * {@code certType}.
     */
    private static ClientCertificateCredential buildCertificateCredential(
            String   tenantId,
            String   clientId,
            CertType certType,
            Path     certPath) {

        ClientCertificateCredentialBuilder builder =
                new ClientCertificateCredentialBuilder()
                        .tenantId(tenantId)
                        .clientId(clientId);

        switch (certType) {

            case JKS -> {
                log.info("Certificate format: JKS — converting to PKCS#12 in memory");
                byte[] pkcs12Bytes = convertJksToPkcs12(certPath);
                // ClientCertificateCredentialBuilder requires a file path; write bytes to temp file
                String tempPfxPath = writePkcs12BytesToTempFile(pkcs12Bytes);
                builder.pfxCertificate(tempPfxPath, new String(TEMP_PKCS12_PASSWORD));
            }

            case PEM -> {
                log.info("Certificate format: PEM");
                builder.pemCertificate(certPath.toString());
            }

            case PFX -> {
                String pfxPassword = AppProperties.getCertPfxPassword();
                log.info("Certificate format: PFX | password-protected: {}",
                         pfxPassword != null);
                builder.pfxCertificate(certPath.toString(), pfxPassword);
            }

            default -> throw new IllegalStateException(
                    "Unsupported certificate type: " + certType);
        }

        return builder.build();
    }

    // =========================================================================
    // Temp file creation
    // =========================================================================

    /**
     * Writes PKCS#12 bytes to a temporary file. The file is marked for
     * automatic deletion on JVM exit to avoid leaving temp files behind.
     *
     * @param pkcs12Bytes PKCS#12-encoded byte array
     * @return absolute path to the temporary file
     * @throws IllegalStateException on write error
     */
    private static String writePkcs12BytesToTempFile(byte[] pkcs12Bytes) {

        try {
            File tempFile = File.createTempFile("azad-cert-", ".p12");
            tempFile.deleteOnExit(); // Ensure cleanup on JVM shutdown

            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(pkcs12Bytes);
                fos.flush();
            }

            String tempPath = tempFile.getAbsolutePath();
            log.debug("PKCS#12 bytes written to temporary file: {}", tempPath);

            return tempPath;

        } catch (Exception e) {
            throw new IllegalStateException(
                "Failed to write PKCS#12 bytes to temporary file: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // JKS → PKCS#12 in-memory conversion
    // =========================================================================

    /**
     * Loads a JKS file, extracts the private key and certificate chain for the
     * configured alias, and serialises them as a PKCS#12 byte array in memory.
     *
     * <h4>Steps</h4>
     * <ol>
     *   <li>Open the JKS with the store password.</li>
     *   <li>Retrieve the {@link PrivateKey} and {@link Certificate}[] for the alias.</li>
     *   <li>Create a fresh in-memory PKCS#12 {@link KeyStore}.</li>
     *   <li>Insert the key entry using a temporary password.</li>
     *   <li>Serialise to a {@code byte[]} — no temp file is ever written.</li>
     * </ol>
     *
     * @param jksPath path to the {@code .jks} file
     * @return PKCS#12-encoded byte array ready to be wrapped in a stream
     * @throws IllegalStateException on any KeyStore loading or conversion error
     */
    private static byte[] convertJksToPkcs12(Path jksPath) {

        String alias         = AppProperties.getCertJksAlias();
        char[] storePassword = AppProperties.getCertStorePassword();
        char[] keyPassword   = AppProperties.getCertJksKeyPassword();

        log.debug("Loading JKS — alias: '{}' | path: {}", alias, jksPath);

        try {
            // ── Step 1: Load the JKS ──────────────────────────────────────
            KeyStore jks = KeyStore.getInstance("JKS");
            try (FileInputStream fis = new FileInputStream(jksPath.toFile())) {
                jks.load(fis, storePassword);
            }

            log.debug("JKS loaded successfully ({} entries)", jks.size());

            // ── Step 2: Validate alias exists ─────────────────────────────
            if (!jks.containsAlias(alias)) {
                throw new IllegalStateException(
                    "Alias '" + alias + "' not found in JKS: " + jksPath +
                    ". Run: keytool -list -keystore " + jksPath + "  to see available aliases.");
            }

            if (!jks.isKeyEntry(alias)) {
                throw new IllegalStateException(
                    "Alias '" + alias + "' exists in JKS but is NOT a key entry " +
                    "(it may be a trusted certificate). A key entry with a private key " +
                    "and certificate chain is required.");
            }

            // ── Step 3: Extract private key and certificate chain ─────────
            PrivateKey   privateKey = (PrivateKey) jks.getKey(alias, keyPassword);
            Certificate[] certChain = jks.getCertificateChain(alias);

            if (privateKey == null) {
                throw new IllegalStateException(
                    "Could not retrieve private key for alias '" + alias +
                    "'. Verify the key password in application.properties.");
            }

            if (certChain == null || certChain.length == 0) {
                throw new IllegalStateException(
                    "No certificate chain found for alias '" + alias + "' in JKS: " + jksPath);
            }

            log.debug("Extracted private key (algo={}) + {} certificate(s) from JKS",
                      privateKey.getAlgorithm(), certChain.length);

            // ── Step 4: Build an in-memory PKCS#12 store ──────────────────
            KeyStore pkcs12 = KeyStore.getInstance("PKCS12");
            pkcs12.load(null, null);  // initialise empty store

            pkcs12.setKeyEntry(alias, privateKey, TEMP_PKCS12_PASSWORD, certChain);

            // ── Step 5: Serialise to byte array (no file on disk) ─────────
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            pkcs12.store(baos, TEMP_PKCS12_PASSWORD);

            byte[] pkcs12Bytes = baos.toByteArray();
            log.debug("In-memory PKCS#12 conversion complete ({} bytes)", pkcs12Bytes.length);

            return pkcs12Bytes;

        } catch (IllegalStateException e) {
            // Re-throw our own validation errors unchanged
            throw e;
        } catch (Exception e) {
            throw new IllegalStateException(
                "Failed to convert JKS to PKCS#12 for alias '" + alias + "': " +
                e.getMessage(), e);
        }
    }
}


