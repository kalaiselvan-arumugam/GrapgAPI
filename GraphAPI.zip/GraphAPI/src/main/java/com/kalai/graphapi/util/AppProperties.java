package com.kalai.graphapi.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Loads {@code application.properties} from the classpath once at startup and
 * exposes strongly-typed accessors for every configuration key.
 *
 * <p>Any mandatory property that is missing or blank causes an
 * {@link IllegalStateException} immediately so the application fails fast
 * with a clear message instead of a cryptic NPE later.
 */
public final class AppProperties {

    private static final Logger log = LogManager.getLogger(AppProperties.class);

    private static final String PROPERTIES_FILE = "application.properties";

    // -------------------------------------------------------------------------
    // Property keys
    // -------------------------------------------------------------------------
    private static final String KEY_TENANT_ID      = "azure.tenant.id";
    private static final String KEY_CLIENT_ID      = "azure.client.id";
    private static final String KEY_AUTH_MODE      = "azure.auth.mode";
    private static final String KEY_CLIENT_SECRET  = "azure.client.secret";
    private static final String KEY_CERT_PATH      = "azure.cert.path";
    private static final String KEY_CERT_PFX_PASS  = "azure.cert.pfx.password";
    private static final String KEY_GROUP_IDS      = "azure.ad.group.ids";
    private static final String KEY_GRAPH_ENDPOINT = "azure.graph.endpoint";
    private static final String KEY_PAGE_SIZE      = "azure.graph.page.size";
    private static final String KEY_PRETTY_PRINT   = "app.output.pretty.print";

    // -------------------------------------------------------------------------
    // Defaults
    // -------------------------------------------------------------------------
    private static final String  DEFAULT_ENDPOINT  = "https://graph.microsoft.com/v1.0";
    private static final int     DEFAULT_PAGE_SIZE = 999;
    private static final boolean DEFAULT_PRETTY    = true;

    // -------------------------------------------------------------------------
    // Authentication modes
    // -------------------------------------------------------------------------
    /**
     * Supported authentication modes, controlled by {@code azure.auth.mode}.
     * <ul>
     *   <li>{@code SECRET} — OAuth2 client secret</li>
     *   <li>{@code PEM}    — PEM file with private key + X.509 certificate</li>
     *   <li>{@code PFX}    — PKCS#12 bundle (.pfx / .p12)</li>
     * </ul>
     */
    public enum AuthMode { SECRET, PEM, PFX }

    // -------------------------------------------------------------------------
    // Loaded properties (singleton, read-only after init)
    // -------------------------------------------------------------------------
    private static final Properties PROPS = loadProperties();

    private AppProperties() {}

    // =========================================================================
    // Internal loader
    // =========================================================================

    private static Properties loadProperties() {
        log.debug("Loading configuration from classpath:{}", PROPERTIES_FILE);
        Properties props = new Properties();
        try (InputStream is = AppProperties.class
                .getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {

            if (is == null) {
                throw new IllegalStateException(
                    "'" + PROPERTIES_FILE + "' not found on the classpath. " +
                    "Ensure it exists under src/main/resources/");
            }
            props.load(is);
            log.debug("Loaded {} properties from {}", props.size(), PROPERTIES_FILE);

        } catch (IOException e) {
            throw new IllegalStateException(
                "Failed to read '" + PROPERTIES_FILE + "': " + e.getMessage(), e);
        }
        return props;
    }

    // =========================================================================
    // Accessors — Azure identity
    // =========================================================================

    /** @return Azure AD Tenant ID (mandatory) */
    public static String getTenantId() {
        return requireNonBlank(KEY_TENANT_ID);
    }

    /** @return Azure Application (Client) ID (mandatory) */
    public static String getClientId() {
        return requireNonBlank(KEY_CLIENT_ID);
    }

    /**
     * Returns the configured authentication mode.
     * Reads {@code azure.auth.mode}; accepted values: SECRET, PEM, PFX.
     *
     * @return {@link AuthMode} enum value (mandatory)
     * @throws IllegalStateException if the value is missing or unrecognised
     */
    public static AuthMode getAuthMode() {
        String raw = requireNonBlank(KEY_AUTH_MODE).toUpperCase();
        try {
            return AuthMode.valueOf(raw);
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException(
                "Property '" + KEY_AUTH_MODE + "' has an unrecognised value '" + raw +
                "'. Allowed values: SECRET, PEM, PFX");
        }
    }

    // =========================================================================
    // Accessors — SECRET mode
    // =========================================================================

    /**
     * Returns the client secret. Only required when {@code azure.auth.mode=SECRET}.
     *
     * @return client secret string (mandatory for SECRET mode)
     * @throws IllegalStateException if missing or blank
     */
    public static String getClientSecret() {
        return requireNonBlank(KEY_CLIENT_SECRET);
    }

    // =========================================================================
    // Accessors — PEM / PFX mode
    // =========================================================================

    /**
     * Resolves and validates the certificate file path.
     * Only required when {@code azure.auth.mode} is PEM or PFX.
     *
     * @return absolute {@link Path} to the certificate file
     * @throws IllegalStateException if the path is blank or the file is missing/unreadable
     */
    public static Path getCertPath() {
        String raw  = requireNonBlank(KEY_CERT_PATH);
        Path   path = Paths.get(raw).toAbsolutePath();

        if (!Files.exists(path)) {
            throw new IllegalStateException(
                "Certificate file not found at '" + path +
                "'. Check '" + KEY_CERT_PATH + "' in " + PROPERTIES_FILE);
        }
        if (!Files.isReadable(path)) {
            throw new IllegalStateException(
                "Certificate file is not readable: '" + path +
                "'. Check file permissions.");
        }

        log.debug("Certificate path resolved: {}", path);
        return path;
    }

    /**
     * Returns the PFX password. Returns {@code null} when blank — the Azure SDK
     * treats {@code null} as "no password".
     *
     * @return password string, or {@code null} if not set
     */
    public static String getCertPfxPassword() {
        String val = PROPS.getProperty(KEY_CERT_PFX_PASS);
        return (val == null || val.isBlank()) ? null : val.trim();
    }

    // =========================================================================
    // Accessors — group IDs
    // =========================================================================

    /**
     * Parses the comma-separated list of AD group Object IDs.
     *
     * @return immutable list with at least one entry
     * @throws IllegalStateException if the property is missing, blank, or empty after parsing
     */
    public static List<String> getGroupIds() {
        String raw = requireNonBlank(KEY_GROUP_IDS);

        List<String> ids = Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();

        if (ids.isEmpty()) {
            throw new IllegalStateException(
                "'" + KEY_GROUP_IDS + "' must contain at least one group Object ID.");
        }

        log.debug("Configured group IDs: {}", ids);
        return ids;
    }

    // =========================================================================
    // Accessors — optional / with defaults
    // =========================================================================

    /** @return Graph API base endpoint URL */
    public static String getGraphEndpoint() {
        String val = PROPS.getProperty(KEY_GRAPH_ENDPOINT, DEFAULT_ENDPOINT).trim();
        return val.isEmpty() ? DEFAULT_ENDPOINT : val;
    }

    /** @return page size for Graph member listing (1–999) */
    public static int getPageSize() {
        String val = PROPS.getProperty(KEY_PAGE_SIZE,
                String.valueOf(DEFAULT_PAGE_SIZE)).trim();
        try {
            int size = Integer.parseInt(val);
            if (size < 1 || size > 999) {
                log.warn("'{}' value {} out of range [1-999]; using default {}",
                         KEY_PAGE_SIZE, size, DEFAULT_PAGE_SIZE);
                return DEFAULT_PAGE_SIZE;
            }
            return size;
        } catch (NumberFormatException e) {
            log.warn("'{}' value '{}' is not an integer; using default {}",
                     KEY_PAGE_SIZE, val, DEFAULT_PAGE_SIZE);
            return DEFAULT_PAGE_SIZE;
        }
    }

    /** @return {@code true} if JSON output should be pretty-printed */
    public static boolean isPrettyPrint() {
        return Boolean.parseBoolean(
            PROPS.getProperty(KEY_PRETTY_PRINT, String.valueOf(DEFAULT_PRETTY)).trim());
    }

    // =========================================================================
    // Helper
    // =========================================================================

    private static String requireNonBlank(String key) {
        String val = PROPS.getProperty(key);
        if (val == null || val.isBlank()) {
            throw new IllegalStateException(
                "Mandatory property '" + key + "' is missing or blank in '"
                + PROPERTIES_FILE + "'.");
        }
        return val.trim();
    }
}
