package com.kalai.graphapi.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Utility class that loads {@code application.properties} from the classpath
 * and exposes strongly-typed accessors for every configuration key.
 *
 * <p>The properties file is read once at class-load time. A fatal error is
 * thrown if any mandatory property is missing or blank so that the application
 * fails fast with a clear message rather than encountering a cryptic NPE later.
 */
public final class AppProperties {

    private static final Logger log = LogManager.getLogger(AppProperties.class);

    /** Classpath location of the properties file. */
    private static final String PROPERTIES_FILE = "application.properties";

    // -------------------------------------------------------------------------
    // Property keys
    // -------------------------------------------------------------------------
    private static final String KEY_TENANT_ID        = "azure.tenant.id";
    private static final String KEY_CLIENT_ID        = "azure.client.id";
    private static final String KEY_CERT_TYPE        = "azure.cert.type";
    private static final String KEY_CERT_PATH        = "azure.cert.path";
    private static final String KEY_CERT_STORE_PASS  = "azure.cert.store.password";
    private static final String KEY_CERT_JKS_ALIAS   = "azure.cert.jks.alias";
    private static final String KEY_CERT_JKS_KEY_PASS= "azure.cert.jks.key.password";
    private static final String KEY_CERT_PFX_PASS    = "azure.cert.pfx.password";
    private static final String KEY_GROUP_IDS        = "azure.ad.group.ids";
    private static final String KEY_GRAPH_ENDPOINT   = "azure.graph.endpoint";
    private static final String KEY_PAGE_SIZE        = "azure.graph.page.size";
    private static final String KEY_PRETTY_PRINT     = "app.output.pretty.print";

    // -------------------------------------------------------------------------
    // Defaults
    // -------------------------------------------------------------------------
    private static final String DEFAULT_ENDPOINT   = "https://graph.microsoft.com/v1.0";
    private static final int    DEFAULT_PAGE_SIZE  = 999;
    private static final boolean DEFAULT_PRETTY    = true;

    // -------------------------------------------------------------------------
    // Supported certificate types
    // -------------------------------------------------------------------------
    public enum CertType { PEM, PFX, JKS }

    // -------------------------------------------------------------------------
    // Singleton-loaded properties object
    // -------------------------------------------------------------------------
    private static final Properties PROPS = loadProperties();

    /** Private constructor — utility class, no instances needed. */
    private AppProperties() {}

    // =========================================================================
    // Loaders
    // =========================================================================

    /**
     * Reads {@code application.properties} from the classpath.
     *
     * @return populated {@link Properties} object
     * @throws IllegalStateException if the file cannot be found or read
     */
    private static Properties loadProperties() {
        log.debug("Loading configuration from classpath:{}", PROPERTIES_FILE);

        Properties props = new Properties();

        try (InputStream is = AppProperties.class
                .getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {

            if (is == null) {
                throw new IllegalStateException(
                    "'" + PROPERTIES_FILE + "' not found on the classpath. " +
                    "Ensure it exists under src/main/resources/");
            }

            props.load(is);
            log.debug("Successfully loaded {} properties", props.size());

        } catch (IOException e) {
            throw new IllegalStateException(
                "Failed to read '" + PROPERTIES_FILE + "': " + e.getMessage(), e);
        }

        return props;
    }

    // =========================================================================
    // Accessors — mandatory properties
    // =========================================================================

    /**
     * @return Azure AD Tenant ID (non-blank, mandatory)
     */
    public static String getTenantId() {
        return requireNonBlank(KEY_TENANT_ID);
    }

    /**
     * @return Azure Application (Client) ID (non-blank, mandatory)
     */
    public static String getClientId() {
        return requireNonBlank(KEY_CLIENT_ID);
    }

    /**
     * Parses and validates the certificate type ({@code PEM} or {@code PFX}).
     *
     * @return {@link CertType} enum value
     * @throws IllegalStateException if the value is missing or unrecognised
     */
    public static CertType getCertType() {
        String raw = requireNonBlank(KEY_CERT_TYPE).toUpperCase();
        try {
            return CertType.valueOf(raw);
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException(
                "Property '" + KEY_CERT_TYPE + "' has an invalid value '" + raw +
                "'. Allowed values: PEM, PFX");
        }
    }

    /**
     * Returns the filesystem path to the certificate file and verifies it exists.
     *
     * <p>Supports both absolute paths and paths relative to the current
     * working directory. The file must be readable at startup.
     *
     * @return absolute {@link Path} to the certificate file
     * @throws IllegalStateException if the path is blank or the file does not exist
     */
    public static Path getCertPath() {
        String raw = requireNonBlank(KEY_CERT_PATH);
        Path path  = Paths.get(raw).toAbsolutePath();

        if (!Files.exists(path)) {
            throw new IllegalStateException(
                "Certificate file not found at path specified by '" + KEY_CERT_PATH +
                "': " + path + ". Verify the path in application.properties.");
        }
        if (!Files.isReadable(path)) {
            throw new IllegalStateException(
                "Certificate file exists but is not readable: " + path +
                ". Check file permissions.");
        }

        log.debug("Certificate file resolved: {}", path);
        return path;
    }

    /**
     * Returns the PFX password. May be empty/null for PEM certificates or
     * unprotected PFX bundles.
     *
     * @return PFX password string, or {@code null} if not configured
     */
    public static String getCertPfxPassword() {
        String val = PROPS.getProperty(KEY_CERT_PFX_PASS);
        return (val == null || val.isBlank()) ? null : val.trim();
    }

    /**
     * Returns the KeyStore / PFX store-level password.
     * Used for both JKS store access and PKCS12 conversion.
     *
     * @return store password char array, or empty array if not configured
     */
    public static char[] getCertStorePassword() {
        String val = PROPS.getProperty(KEY_CERT_STORE_PASS);
        return (val == null || val.isBlank()) ? new char[0] : val.toCharArray();
    }

    /**
     * Returns the alias of the key entry inside a JKS that holds the
     * private key + certificate chain to be used for authentication.
     *
     * <p>Run {@code keytool -list -keystore your.jks} to list available aliases.
     *
     * @return JKS alias (non-blank, mandatory when cert type is JKS)
     */
    public static String getCertJksAlias() {
        return requireNonBlank(KEY_CERT_JKS_ALIAS);
    }

    /**
     * Returns the password protecting the specific key entry (alias) inside a JKS.
     * Defaults to the store password when not explicitly set.
     *
     * @return key-entry password char array
     */
    public static char[] getCertJksKeyPassword() {
        String val = PROPS.getProperty(KEY_CERT_JKS_KEY_PASS);
        if (val == null || val.isBlank()) {
            // Fall back to the store password (common convention)
            return getCertStorePassword();
        }
        return val.toCharArray();
    }

    /**
     * Parses the comma-separated list of AD group Object IDs.
     *
     * @return immutable list of trimmed, non-empty group IDs (at least one)
     */
    public static List<String> getGroupIds() {
        String raw = requireNonBlank(KEY_GROUP_IDS);

        List<String> ids = Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();

        if (ids.isEmpty()) {
            throw new IllegalStateException(
                "'" + KEY_GROUP_IDS + "' must contain at least one group Object ID.");
        }

        log.debug("Configured group IDs: {}", ids);
        return ids;
    }

    // =========================================================================
    // Accessors — optional properties (with defaults)
    // =========================================================================

    /**
     * @return Microsoft Graph base endpoint URL
     */
    public static String getGraphEndpoint() {
        String val = PROPS.getProperty(KEY_GRAPH_ENDPOINT, DEFAULT_ENDPOINT).trim();
        return val.isEmpty() ? DEFAULT_ENDPOINT : val;
    }

    /**
     * @return page size for Graph API member listing (1–999)
     */
    public static int getPageSize() {
        String val = PROPS.getProperty(KEY_PAGE_SIZE, String.valueOf(DEFAULT_PAGE_SIZE)).trim();
        try {
            int size = Integer.parseInt(val);
            if (size < 1 || size > 999) {
                log.warn("'{}' value {} is out of range [1-999]; using default {}",
                         KEY_PAGE_SIZE, size, DEFAULT_PAGE_SIZE);
                return DEFAULT_PAGE_SIZE;
            }
            return size;
        } catch (NumberFormatException e) {
            log.warn("'{}' value '{}' is not a valid integer; using default {}",
                     KEY_PAGE_SIZE, val, DEFAULT_PAGE_SIZE);
            return DEFAULT_PAGE_SIZE;
        }
    }

    /**
     * @return {@code true} if the JSON summary should be pretty-printed
     */
    public static boolean isPrettyPrint() {
        String val = PROPS.getProperty(KEY_PRETTY_PRINT,
                String.valueOf(DEFAULT_PRETTY)).trim();
        return Boolean.parseBoolean(val);
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /**
     * Returns the trimmed value for {@code key}, throwing if absent or blank.
     *
     * @param key property key
     * @return non-blank trimmed value
     * @throws IllegalStateException when the property is missing or blank
     */
    private static String requireNonBlank(String key) {
        String val = PROPS.getProperty(key);
        if (val == null || val.isBlank()) {
            throw new IllegalStateException(
                "Mandatory property '" + key + "' is missing or blank in " +
                PROPERTIES_FILE + ". Please set a valid value.");
        }
        return val.trim();
    }
}

