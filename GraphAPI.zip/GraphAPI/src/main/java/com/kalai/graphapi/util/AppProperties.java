package com.kalai.graphapi.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Loads {@code application.properties} from the classpath once at startup and
 * exposes strongly-typed accessors for every configuration key.
 *
 * <p>Any mandatory property that is missing or blank causes an
 * {@link IllegalStateException} immediately so the application fails fast
 * with a clear message instead of a cryptic error later.
 */
public final class AppProperties {

    private static final Logger log = LogManager.getLogger(AppProperties.class);

    private static final String PROPERTIES_FILE = "application.properties";

    // -------------------------------------------------------------------------
    // Property keys
    // -------------------------------------------------------------------------
    private static final String KEY_TENANT_ID           = "azure.tenant.id";
    private static final String KEY_CLIENT_ID           = "azure.client.id";
    private static final String KEY_CLIENT_SECRET       = "azure.client.secret";
    private static final String KEY_GROUP_IDS           = "azure.ad.group.ids";
    private static final String KEY_GRAPH_ENDPOINT      = "azure.graph.endpoint";
    private static final String KEY_PAGE_SIZE           = "azure.graph.page.size";
    private static final String KEY_PRETTY_PRINT        = "app.output.pretty.print";
    private static final String KEY_SSL_FIX_ENABLED     = "ssl.trust.fix.enabled";
    private static final String KEY_SSL_FIX_CERT_PATH   = "ssl.trust.fix.cert.path";

    // -------------------------------------------------------------------------
    // Defaults
    // -------------------------------------------------------------------------
    private static final String  DEFAULT_ENDPOINT  = "https://graph.microsoft.com/v1.0";
    private static final int     DEFAULT_PAGE_SIZE = 999;
    private static final boolean DEFAULT_PRETTY    = true;
    private static final boolean DEFAULT_SSL_FIX   = true;

    // -------------------------------------------------------------------------
    // Loaded properties (read-only after init)
    // -------------------------------------------------------------------------
    private static final Properties PROPS = loadProperties();

    private AppProperties() {}

    // =========================================================================
    // Internal loader
    // =========================================================================

    private static Properties loadProperties() {
        log.debug("Loading configuration from classpath:{}", PROPERTIES_FILE);
        Properties props = new Properties();
        try (InputStream is = AppProperties.class
                .getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {

            if (is == null) {
                throw new IllegalStateException(
                    "'" + PROPERTIES_FILE + "' not found on the classpath. " +
                    "Ensure it exists under src/main/resources/");
            }
            props.load(is);
            log.debug("Loaded {} properties from {}", props.size(), PROPERTIES_FILE);

        } catch (IOException e) {
            throw new IllegalStateException(
                "Failed to read '" + PROPERTIES_FILE + "': " + e.getMessage(), e);
        }
        return props;
    }

    // =========================================================================
    // Accessors — Azure identity (all mandatory)
    // =========================================================================

    /**
     * @return Azure AD Tenant (Directory) ID
     */
    public static String getTenantId() {
        return requireNonBlank(KEY_TENANT_ID);
    }

    /**
     * @return Azure Application (Client) ID
     */
    public static String getClientId() {
        return requireNonBlank(KEY_CLIENT_ID);
    }

    /**
     * @return Client secret value
     */
    public static String getClientSecret() {
        return requireNonBlank(KEY_CLIENT_SECRET);
    }

    // =========================================================================
    // Accessors — group IDs (mandatory)
    // =========================================================================

    /**
     * Parses the comma-separated list of AD group Object IDs.
     *
     * @return immutable list with at least one entry
     * @throws IllegalStateException if missing, blank, or empty after parsing
     */
    public static List<String> getGroupIds() {
        String raw = requireNonBlank(KEY_GROUP_IDS);

        List<String> ids = Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();

        if (ids.isEmpty()) {
            throw new IllegalStateException(
                "'" + KEY_GROUP_IDS + "' must contain at least one group Object ID.");
        }

        log.debug("Configured group IDs: {}", ids);
        return ids;
    }

    // =========================================================================
    // Accessors — optional / with defaults
    // =========================================================================

    /**
     * @return Graph API base endpoint URL
     */
    public static String getGraphEndpoint() {
        String val = PROPS.getProperty(KEY_GRAPH_ENDPOINT, DEFAULT_ENDPOINT).trim();
        return val.isEmpty() ? DEFAULT_ENDPOINT : val;
    }

    /**
     * @return page size for Graph member listing (1–999)
     */
    public static int getPageSize() {
        String val = PROPS.getProperty(KEY_PAGE_SIZE,
                String.valueOf(DEFAULT_PAGE_SIZE)).trim();
        try {
            int size = Integer.parseInt(val);
            if (size < 1 || size > 999) {
                log.warn("'{}' value {} out of range [1-999]; using default {}",
                         KEY_PAGE_SIZE, size, DEFAULT_PAGE_SIZE);
                return DEFAULT_PAGE_SIZE;
            }
            return size;
        } catch (NumberFormatException e) {
            log.warn("'{}' value '{}' is not an integer; using default {}",
                     KEY_PAGE_SIZE, val, DEFAULT_PAGE_SIZE);
            return DEFAULT_PAGE_SIZE;
        }
    }

    /**
     * @return {@code true} if JSON output should be pretty-printed
     */
    public static boolean isPrettyPrint() {
        return Boolean.parseBoolean(
            PROPS.getProperty(KEY_PRETTY_PRINT,
                String.valueOf(DEFAULT_PRETTY)).trim());
    }

    // =========================================================================
    // Accessors — SSL / PKIX fix
    // =========================================================================

    /**
     * @return {@code true} if the programmatic SSL trust fix should run at startup
     */
    public static boolean isSslTrustFixEnabled() {
        return Boolean.parseBoolean(
            PROPS.getProperty(KEY_SSL_FIX_ENABLED,
                String.valueOf(DEFAULT_SSL_FIX)).trim());
    }

    /**
     * @return classpath-relative path to the Microsoft intermediate CA PEM file
     */
    public static String getSslTrustFixCertPath() {
        String val = PROPS.getProperty(KEY_SSL_FIX_CERT_PATH, "certs/ms-azure-tls-ca.pem").trim();
        return val.isEmpty() ? "certs/ms-azure-tls-ca.pem" : val;
    }

    // =========================================================================
    // Helper
    // =========================================================================

    private static String requireNonBlank(String key) {
        String val = PROPS.getProperty(key);
        if (val == null || val.isBlank()) {
            throw new IllegalStateException(
                "Mandatory property '" + key + "' is missing or blank in '"
                + PROPERTIES_FILE + "'.");
        }
        return val.trim();
    }
}
