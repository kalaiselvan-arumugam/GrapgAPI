package com.kalai.graphapi.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Utility class that loads {@code application.properties} from the classpath
 * and exposes strongly-typed accessors for every configuration key.
 *
 * <p>The properties file is read once at class-load time. A fatal error is
 * thrown if any mandatory property is missing or blank so that the application
 * fails fast with a clear message rather than encountering a cryptic NPE later.
 */
public final class AppProperties {

    private static final Logger log = LogManager.getLogger(AppProperties.class);

    /** Classpath location of the properties file. */
    private static final String PROPERTIES_FILE = "application.properties";

    // -------------------------------------------------------------------------
    // Property keys
    // -------------------------------------------------------------------------
    private static final String KEY_TENANT_ID       = "azure.tenant.id";
    private static final String KEY_CLIENT_ID       = "azure.client.id";
    private static final String KEY_CLIENT_SECRET   = "azure.client.secret";
    private static final String KEY_GROUP_IDS       = "azure.ad.group.ids";
    private static final String KEY_GRAPH_ENDPOINT  = "azure.graph.endpoint";
    private static final String KEY_PAGE_SIZE       = "azure.graph.page.size";
    private static final String KEY_PRETTY_PRINT    = "app.output.pretty.print";

    // -------------------------------------------------------------------------
    // Defaults
    // -------------------------------------------------------------------------
    private static final String DEFAULT_ENDPOINT   = "https://graph.microsoft.com/v1.0";
    private static final int    DEFAULT_PAGE_SIZE  = 999;
    private static final boolean DEFAULT_PRETTY    = true;

    // -------------------------------------------------------------------------
    // Singleton-loaded properties object
    // -------------------------------------------------------------------------
    private static final Properties PROPS = loadProperties();

    /** Private constructor — utility class, no instances needed. */
    private AppProperties() {}

    // =========================================================================
    // Loaders
    // =========================================================================

    /**
     * Reads {@code application.properties} from the classpath.
     *
     * @return populated {@link Properties} object
     * @throws IllegalStateException if the file cannot be found or read
     */
    private static Properties loadProperties() {
        log.debug("Loading configuration from classpath:{}", PROPERTIES_FILE);

        Properties props = new Properties();

        try (InputStream is = AppProperties.class
                .getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {

            if (is == null) {
                throw new IllegalStateException(
                    "'" + PROPERTIES_FILE + "' not found on the classpath. " +
                    "Ensure it exists under src/main/resources/");
            }

            props.load(is);
            log.debug("Successfully loaded {} properties", props.size());

        } catch (IOException e) {
            throw new IllegalStateException(
                "Failed to read '" + PROPERTIES_FILE + "': " + e.getMessage(), e);
        }

        return props;
    }

    // =========================================================================
    // Accessors — mandatory properties
    // =========================================================================

    /**
     * @return Azure AD Tenant ID (non-blank, mandatory)
     */
    public static String getTenantId() {
        return requireNonBlank(KEY_TENANT_ID);
    }

    /**
     * @return Azure Application (Client) ID (non-blank, mandatory)
     */
    public static String getClientId() {
        return requireNonBlank(KEY_CLIENT_ID);
    }

    /**
     * @return Azure Client Secret value (non-blank, mandatory)
     */
    public static String getClientSecret() {
        return requireNonBlank(KEY_CLIENT_SECRET);
    }

    /**
     * Parses the comma-separated list of AD group Object IDs.
     *
     * @return immutable list of trimmed, non-empty group IDs (at least one)
     */
    public static List<String> getGroupIds() {
        String raw = requireNonBlank(KEY_GROUP_IDS);

        List<String> ids = Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList(); // Java 16+ unmodifiable list

        if (ids.isEmpty()) {
            throw new IllegalStateException(
                "'" + KEY_GROUP_IDS + "' must contain at least one group Object ID.");
        }

        log.debug("Configured group IDs: {}", ids);
        return ids;
    }

    // =========================================================================
    // Accessors — optional properties (with defaults)
    // =========================================================================

    /**
     * @return Microsoft Graph base endpoint URL
     */
    public static String getGraphEndpoint() {
        String val = PROPS.getProperty(KEY_GRAPH_ENDPOINT, DEFAULT_ENDPOINT).trim();
        return val.isEmpty() ? DEFAULT_ENDPOINT : val;
    }

    /**
     * @return page size for Graph API member listing (1–999)
     */
    public static int getPageSize() {
        String val = PROPS.getProperty(KEY_PAGE_SIZE, String.valueOf(DEFAULT_PAGE_SIZE)).trim();
        try {
            int size = Integer.parseInt(val);
            if (size < 1 || size > 999) {
                log.warn("'{}' value {} is out of range [1-999]; using default {}",
                         KEY_PAGE_SIZE, size, DEFAULT_PAGE_SIZE);
                return DEFAULT_PAGE_SIZE;
            }
            return size;
        } catch (NumberFormatException e) {
            log.warn("'{}' value '{}' is not a valid integer; using default {}",
                     KEY_PAGE_SIZE, val, DEFAULT_PAGE_SIZE);
            return DEFAULT_PAGE_SIZE;
        }
    }

    /**
     * @return {@code true} if the JSON summary should be pretty-printed
     */
    public static boolean isPrettyPrint() {
        String val = PROPS.getProperty(KEY_PRETTY_PRINT,
                String.valueOf(DEFAULT_PRETTY)).trim();
        return Boolean.parseBoolean(val);
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /**
     * Returns the trimmed value for {@code key}, throwing if absent or blank.
     *
     * @param key property key
     * @return non-blank trimmed value
     * @throws IllegalStateException when the property is missing or blank
     */
    private static String requireNonBlank(String key) {
        String val = PROPS.getProperty(key);
        if (val == null || val.isBlank()) {
            throw new IllegalStateException(
                "Mandatory property '" + key + "' is missing or blank in " +
                PROPERTIES_FILE + ". Please set a valid value.");
        }
        return val.trim();
    }
}
